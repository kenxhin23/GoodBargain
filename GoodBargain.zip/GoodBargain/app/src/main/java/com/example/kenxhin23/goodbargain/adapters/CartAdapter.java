package com.example.kenxhin23.goodbargain.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.Cart;
import com.example.kenxhin23.goodbargain.model.Category;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kenxhin23 on 7/30/2020.
 */

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {

    Context context;
    List<Cart> CartInfoList;
    List<ProductInfo> ProductInfoList;
    OnItemClickListener cartListener;
    String userKey, cusID, cartid, url;
    double amt, price;
    int Qty;
    DatabaseReference dbCart, dbProduct;
    ProductInfo p;
    private FirebaseAuth auth;
    public List<Cart> list = new ArrayList<>();
    ArrayList<Cart> listt = new ArrayList<>();
    private int totalAmt;


    public interface OnItemClickListener{
        void onItemClick (int position);
    }

    public void remove(int position) {
        this.CartInfoList.remove(position);
    }


    public void setOnItemClickListener(OnItemClickListener listener){
        cartListener = listener;
    }



    public CartAdapter(Context context, List<Cart> TempList){
        this.CartInfoList = TempList;
        this.context = context;
    }

    public void setItems(ArrayList<Cart> cart)
    {
        listt.addAll(cart);
    }



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_cart, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        Cart cart = CartInfoList.get(position);

        holder.qty.setText("Quantity: "+cart.getQuantity());
        holder.productName.setText(cart.getProduct());
        holder.amount.setText(String.format("₱ %.2f", cart.getAmount()));
        Glide.with(context).load(cart.getUrl()).into(holder.itemImage);

    }

    @Override
    public int getItemCount() {
        return CartInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView itemImage;
        public TextView productName, qty, amount, remove;

        public ViewHolder (View itemView){
            super(itemView);

            itemImage = (ImageView) itemView.findViewById(R.id.img_item);
            productName = (TextView) itemView.findViewById(R.id.productName);
            qty = (TextView) itemView.findViewById(R.id.quantity);
            amount = (TextView) itemView.findViewById(R.id.amount);
//            remove = (TextView) itemView.findViewById(R.id.txt_option);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(cartListener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            cartListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }

}
