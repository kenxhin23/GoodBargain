package com.example.kenxhin23.goodbargain.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.kenxhin23.goodbargain.checkout_section.CategoryFragment;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.example.kenxhin23.goodbargain.R;

import java.util.List;

/**
 * Created by kenxhin23 on 2/6/2020.
 */


public class ProdAdapter extends RecyclerView.Adapter<ProdAdapter.ViewHolder>{

    Context context;
    List<ProductInfo> ProductInfoList;
    OnItemClickListener mListener;


    public interface OnItemClickListener{
        void onItemClick (int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public ProdAdapter(Context context, List<ProductInfo> TempList){
        this.ProductInfoList = TempList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_prod, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        ProductInfo productInfo = ProductInfoList.get(position);
        holder.itemName.setText(productInfo.getItemName());
        holder.price.setText(String.format("₱%.2f",productInfo.getPrice()));
        holder.stock.setText("Inventory: "+productInfo.getStock());
        Glide.with(context).load(productInfo.getImageUrl()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return ProductInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView imageView;
        public TextView itemName, price, stock;

        public ViewHolder (View itemView){
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.itemView);
            itemName = (TextView) itemView.findViewById(R.id.pName);
            price = (TextView) itemView.findViewById(R.id.price);
            stock = (TextView) itemView.findViewById(R.id.stock);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mListener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            mListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
