package com.example.kenxhin23.goodbargain.admin_section;

import android.app.ProgressDialog;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.User_Info;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class AddUsers extends AppCompatActivity {

    private EditText userName, contact, pin, type;
    private TextInputLayout layoutName, layoutContact, layoutPin, layoutType;
    private Button saveUser;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
    String pid;
    Uri FilePathUri;
    ProgressDialog progressDialog;
    FirebaseDatabase db;
    StorageReference storageReference;
    DatabaseReference databaseReference;
    private final static int MY_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_users);
        setTitle("Add User");

        storageReference = FirebaseStorage.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userKey);

        init();

        progressDialog = new ProgressDialog(AddUsers.this);

        saveUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addUser();
            }
        });


    }

    public void addUser() {


        String id = databaseReference.push().getKey();
        String name = userName.getText().toString().trim();
        String con = contact.getText().toString().trim();
        String pin1 = pin.getText().toString().trim();
        String utype = type.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            layoutName.setError("Enter Name");
            return;
        }
        if (TextUtils.isEmpty(con)) {
            layoutContact.setError("Enter Contact Number");
            return;
        }
        if (TextUtils.isEmpty(utype)) {
            layoutType.setError("Please input user type");
            return;
        }
        if (pin1.length() < 4) {
            layoutPin.setError("Enter at least 4 digits");
            return;
        }
        if (pin1.length() > 4) {
            layoutPin.setError("Please enter not more than 4 digits");
            return;
        }


        progressDialog.setTitle("Saving...");
        progressDialog.show();

        User_Info userInfo = new User_Info(
                id,
                name,
                con,
                pin1,
                utype);
        databaseReference.child(id).setValue(userInfo)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {


                        Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
                        progressDialog.dismiss();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        progressDialog.dismiss();
                        Toast.makeText(AddUsers.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void init() {

        userName = (EditText) findViewById(R.id.editUsername);
        contact = (EditText) findViewById(R.id.editContact);
        pin = (EditText) findViewById(R.id.editPin);
        type = (EditText) findViewById(R.id.editType);
        saveUser = (Button) findViewById(R.id.saveUser);
        layoutName = (TextInputLayout) findViewById(R.id.layoutUsername);
        layoutContact = (TextInputLayout) findViewById(R.id.layoutContact);
        layoutPin = (TextInputLayout) findViewById(R.id.layoutPin);
        layoutType = (TextInputLayout) findViewById(R.id.layoutType);
    }
}