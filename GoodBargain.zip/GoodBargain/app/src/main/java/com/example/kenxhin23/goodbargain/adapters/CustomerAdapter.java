package com.example.kenxhin23.goodbargain.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.Customer;

import java.util.List;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.ViewHolder>{

    Context context;
    List<Customer> CustomerList;
    OnItemClickListener cusListener;

    public interface OnItemClickListener{
        void onItemClick (int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        cusListener = listener;
    }

    public CustomerAdapter(Context context, List<Customer> TempList) {
        this.context = context;
        this.CustomerList = TempList;
    }

    @Override
    public CustomerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_customer, parent, false);
        CustomerAdapter.ViewHolder viewHolder = new CustomerAdapter.ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(CustomerAdapter.ViewHolder holder, int position) {

        Customer customer = CustomerList.get(position);

        holder.name.setText(customer.getCusName());

    }

    @Override
    public int getItemCount() {
        return CustomerList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView name;

        public ViewHolder(View view) {
            super(view);

            name = (TextView) view.findViewById(R.id.customer);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (cusListener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            cusListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
