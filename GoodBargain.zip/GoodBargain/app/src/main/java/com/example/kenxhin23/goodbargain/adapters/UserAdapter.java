package com.example.kenxhin23.goodbargain.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.User_Info;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    Context context;
    List<User_Info> userInfoList;
    OnItemClickListener uListener;

    public interface OnItemClickListener{
        void onItemClick (int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        uListener = listener;
    }

    public UserAdapter(Context context, List<User_Info> TempList){
        this.userInfoList = TempList;
        this.context = context;
    }

    @Override
    public UserAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_users, parent, false);
        UserAdapter.ViewHolder viewHolder = new UserAdapter.ViewHolder(view);

        return viewHolder;

    }

    @Override
    public void onBindViewHolder(UserAdapter.ViewHolder holder, int position) {

        User_Info userInfo = userInfoList.get(position);

        holder.userName.setText("Name: " +userInfo.getUserName());
        holder.uContact.setText("Contact No. " +userInfo.getContacts());
        holder.uType.setText("Type: " +userInfo.getType());
    }

    @Override
    public int getItemCount() {
        return userInfoList.size();
    }


    class ViewHolder extends RecyclerView.ViewHolder{

        public TextView userName, uContact, uType;

        public ViewHolder(View itemView) {
            super(itemView);

            userName = (TextView) itemView.findViewById(R.id.userName);
            uContact = (TextView) itemView.findViewById(R.id.userContact);
            uType = (TextView) itemView.findViewById(R.id.userType);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(uListener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            uListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}
