package com.example.kenxhin23.goodbargain.model;

public class Customer {

    private String custID;
    private String name;

    public Customer(){

    }

    public Customer(String custID, String name){
        this.custID = custID;
        this.name = name;
    }

    public String getCustID() {
        return custID;
    }

    public void setID(String custID) {
        this.custID = custID;
    }

    public String getCusName() {
        return name;
    }

    public void setCusName(String name) {
        this.name = name;
    }
}
