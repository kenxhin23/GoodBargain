package com.example.kenxhin23.goodbargain.model;

/**
 * Created by kenxhin23 on 7/30/2020.
 */

public class Cart {

    private String id;
    private String custID;
    private String product;
    private String productID;
    private String quantity;
    private String url;
    double amount;
    double camount;


    public Cart(){

    }

    public Cart( String id, String custID, String product, String productID, String quantity, double amount, double camount, String url) {

        this.id = id;
        this.custID = custID;
        this.product = product;
        this.productID = productID;
        this.quantity = quantity;
        this.amount = amount;
        this.camount = camount;
        this.url = url;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getCustID() {
        return custID;
    }

    public void setCustID(String custID) {
        this.custID = custID;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getCamount() {
        return camount;
    }

    public void setCamount(double camount) {
        this.camount = camount;
    }

}
