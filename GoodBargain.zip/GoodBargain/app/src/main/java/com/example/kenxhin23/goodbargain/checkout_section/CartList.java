package com.example.kenxhin23.goodbargain.checkout_section;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ParseException;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.CartAdapter;
import com.example.kenxhin23.goodbargain.model.Cart;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.example.kenxhin23.goodbargain.model.Transactions;
import com.example.kenxhin23.goodbargain.model.User_Info;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CartList extends AppCompatActivity implements CartAdapter.OnItemClickListener {

    Context context = getApplication();
    SwipeRefreshLayout swipeRefresh;
    RecyclerView recyclerCart;
    ImageView cancelDiscount;
    Button checkout;
    TextView totalAmount, addDiscount, subTotalText, subTotal, discounted,
            percent, cash ;
    LinearLayout discountLayout, addDiscountLayout, subTotalLayout;
    private FirebaseAuth auth;
    ProgressDialog progressDialog;
    CartAdapter cartAdapter = null;
    List<Cart> list = new ArrayList<>();
    DatabaseReference dbCart, dbOrder, dbProduct, dbTrans, dbUser, dbCus;
    int newStk, Stk, Qty, Qtyy;
    double totalAmt = 0.00, amt = 0.00, sbTotal = 0.00, dis = 0.00, camount = 0.00;
    String cusID, cus, userKey, cartid, qty, cartID, pname, stk, pid, dateTime, pin;
    String img, cat, desc, keys;
    double price, cost, costAmt, pay, change;
    Query query1, query2;
    Cart cart;
    Customer customer;
    SwipeController swipeController = null;
    boolean isLoading=false;
    private final static int MY_REQUEST_CODE = 1;

    private TextWatcher text = null, textt = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_list);

        Intent i = getIntent();
        cusID = i.getExtras().getString("cusID");
        cus = i.getExtras().getString("cname");
        setTitle("Cart: "+cus);

        init();
        hide();

        LinearLayoutManager manager = new LinearLayoutManager(CartList.this);
        recyclerCart.setLayoutManager(manager);
        recyclerCart.setHasFixedSize(true);
//        recyclerCart.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        progressDialog = new ProgressDialog(CartList.this);
        progressDialog.setMessage("Loading...");

        cartAdapter = new CartAdapter(CartList.this, list);
        recyclerCart.setAdapter(cartAdapter);
        cartAdapter.setOnItemClickListener(CartList.this);

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        userKey = store.getUid();
        dbCart = FirebaseDatabase.getInstance().getReference("Cart").child(userKey);
        dbOrder = FirebaseDatabase.getInstance().getReference("Orders").child(userKey);
        dbProduct = FirebaseDatabase.getInstance().getReference("Products").child(userKey);
        dbTrans = FirebaseDatabase.getInstance().getReference("Transactions").child(userKey);

        query2 = dbProduct.orderByChild("id").equalTo(pid);
        query2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    ProductInfo productInfo = postSnapshot.getValue(ProductInfo.class);
                    stk = productInfo.getStock();
                    cat = productInfo.getCategory();
                    price = productInfo.getPrice();
                    desc = productInfo.getDescription();
                    cost = productInfo.getCost();
                    img = productInfo.getImageUrl();

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                
                if (list.isEmpty()){
                    Toast.makeText(CartList.this, "Cart is empty!", Toast.LENGTH_SHORT).show();
                    cus = "";
                } else {
                    payment();
                }
//                Toast.makeText(CartList.this, "" + dateTime, Toast.LENGTH_SHORT).show();
            }
        });

        cancelDiscount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dis -= dis;
                totalAmt -=  totalAmt;

                if (totalAmt == 0) {
                    totalAmt = sbTotal;
                    totalAmount.setText(String.format("₱%.2f", totalAmt));
                }

                totalAmount.setText(String.format("₱%.2f", totalAmt));
                addDiscountLayout.setVisibility(View.VISIBLE);
                discountLayout.setVisibility(View.GONE);
            }
        });


        result();
        addDisc();
        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                int color = getResources().getColor(R.color.colorPrimary);
                swipeRefresh.setColorSchemeColors(color);
                result();
                swipeRefresh.setRefreshing(false);
            }
        });

    }

    public void transactions() {

        Long tsLong = System.currentTimeMillis() / 1000;
        String ts = tsLong.toString();

        SimpleDateFormat sfd = new SimpleDateFormat("dd-MM-yyyy");
        try {
            Date date = new Date();
            dateTime = sfd.format(date);
            System.out.println("Current Date Time : " + dateTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        dbTrans = FirebaseDatabase.getInstance().getReference("Transactions").child(userKey);

        if (totalAmt == sbTotal){
            String tid = dbTrans.push().getKey();
            Transactions trans = new Transactions(
                    tid,
                    cusID,
                    dis,
                    totalAmt,
                    camount,
                    dateTime
            );
            dbTrans.child(tid).setValue(trans).
                    addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(CartList.this, "Placed order successfully!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    });
        } else {
            String tid = dbTrans.push().getKey();
            Transactions trans = new Transactions(
                    tid,
                    cusID,
                    dis,
                    sbTotal,
                    camount,
                    dateTime
            );
            dbTrans.child(tid).setValue(trans).
                    addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(CartList.this, "Placed order successfully!", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    });
        }

    }

    public void removeCart() {

        dbCart = FirebaseDatabase.getInstance().getReference("Cart").child(userKey).child(cusID);
        dbCart.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    cart = ds.getValue(Cart.class);

                    ds.getRef().removeValue();
                }

                finish();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }



    public void init(){

        swipeRefresh = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh);
        recyclerCart = (RecyclerView) findViewById(R.id.recyclerCart);
        checkout = (Button) findViewById(R.id.checkout);
        totalAmount = (TextView) findViewById(R.id.totalAmount);
        subTotalText = (TextView) findViewById(R.id.subTotalText);
        subTotal = (TextView) findViewById(R.id.subTotal);
        discounted = (TextView) findViewById(R.id.discounted);
        percent = (TextView) findViewById(R.id.percent);
        cash = (TextView) findViewById(R.id.cash);
        addDiscount = (TextView) findViewById(R.id.addDiscount);
        cancelDiscount = (ImageView) findViewById(R.id.cancelDiscount);
        discountLayout = (LinearLayout) findViewById(R.id.discountLayout);
        addDiscountLayout = (LinearLayout) findViewById(R.id.addDiscountLayout);
        subTotalLayout = (LinearLayout) findViewById(R.id.subTotalLayout);

    }


    public void result(){

        dbCart = FirebaseDatabase.getInstance().getReference("Cart").child(userKey).child(cusID);
        dbCart.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                list.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    Cart cart = postSnapshot.getValue(Cart.class);

                    list.add(cart);
                    amt = cart.getAmount();
                    costAmt = cart.getCamount();
                    if (amt != 0) {
                        subTotalLayout.setVisibility(View.VISIBLE);
                        sbTotal += amt;
                        camount += costAmt;

                    }
                    totalAmt = sbTotal;
                    subTotal.setText(String.format("₱%.2f", sbTotal));
                    totalAmount.setText(String.format("₱%.2f", totalAmt));
                }
                cartAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

//        dbCart = FirebaseDatabase.getInstance().getReference("Cart").child(userKey).child(cusID);
//        query1 = dbCart.child(cusID).orderByChild("custID").equalTo(cusID);
    }

    public void hide(){


//        subTotalText.setVisibility(View.GONE);
//        subTotal.setVisibility(View.GONE);
//        discounted.setVisibility(View.GONE);
//        percent.setVisibility(View.GONE);
//        cash.setVisibility(View.GONE);
//        cancelDiscount.setVisibility(View.GONE);
        subTotalLayout.setVisibility(View.GONE);
        discountLayout.setVisibility(View.GONE);
    }

    public void addDisc(){
        addDiscount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TextView title = new TextView(CartList.this);
                title.setText(String.format("Apply discount on ₱%.2f",sbTotal));
                title.setPadding(10, 10, 10, 10);
                title.setGravity(Gravity.CENTER);
                title.setTextSize(23);

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(CartList.this);
                LayoutInflater inflater = LayoutInflater.from(CartList.this);
                final View dialogView = inflater.inflate(R.layout.add_discount, null);
                dialogBuilder.setView(dialogView);

               final EditText editCash = (EditText) dialogView.findViewById(R.id.editCash);
                final Button addDis = (Button) dialogView.findViewById(R.id.buttonAddDiscount);

                dialogBuilder.setCustomTitle(title);
                final AlertDialog b = dialogBuilder.create();
                b.show();

                addDis.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        if (TextUtils.isEmpty(editCash.getText().toString())) {
                            Toast.makeText(CartList.this, "Enter amount first!", Toast.LENGTH_SHORT).show();


                        } else {

                            dis = Double.parseDouble(editCash.getText().toString().trim());

                            if (dis > sbTotal){
                                Toast.makeText(CartList.this, "Must lower than sub total!", Toast.LENGTH_SHORT).show();
                            } else {

                                totalAmt = sbTotal - dis;

                                totalAmount.setText(String.format("₱%.2f", totalAmt));
                                discountLayout.setVisibility(View.VISIBLE);
                                cash.setText(String.format("₱%.2f", dis));
                                addDiscountLayout.setVisibility(View.GONE);
                            }
                        }
                        b.dismiss();
                    }
                });
            }
        });
    }

    @Override
    public void onItemClick(final int position) {

      cart = list.get(position);
        cartid = cart.getID();
        qty = cart.getQuantity();
        pid = cart.getProductID();
        cusID = cart.getCustID();
        pname = cart.getProduct();



        Intent i = new Intent(CartList.this, CancelItem.class);
        i.putExtra("pid", pid);
        i.putExtra("qty", qty);
        i.putExtra("cusID", cusID);
        i.putExtra("cartID", cartid);
        i.putExtra("cus", cus);
        startActivity(i);
        finish();
    }

    private void moveRecord(DatabaseReference fromPath, final DatabaseReference toPath) {

        dbOrder = FirebaseDatabase.getInstance().getReference("Orders").child(userKey).child(cusID);
        final String orderID = dbOrder.push().getKey();
        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                toPath.child(orderID).setValue(dataSnapshot.getValue()).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isComplete()) {
                            Toast.makeText(CartList.this, "Placed order successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(CartList.this, "Try again!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(CartList.this, "No network connection!", Toast.LENGTH_SHORT).show();
            }
        };
        fromPath.addListenerForSingleValueEvent(valueEventListener);
    }

    public void inputPin() {

        TextView title = new TextView(CartList.this);
        title.setText(String.format("Change: ₱%.2f", change));
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(CartList.this);
        LayoutInflater inflater = LayoutInflater.from(CartList.this);
        final View dialogView = inflater.inflate(R.layout.user_pin, null);
        dialogBuilder.setView(dialogView);

        final EditText inputPin = (EditText) dialogView.findViewById(R.id.userPin);
        final Button btnOk = (Button) dialogView.findViewById(R.id.userConfirm);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                pin = inputPin.getText().toString().trim();

                if (TextUtils.isEmpty(pin)){
                    Toast.makeText(CartList.this, "Enter Pin!", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbUser = FirebaseDatabase.getInstance().getReference().child("Users").child(userKey);
                dbUser.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        User_Info user = dataSnapshot.getChildren().iterator().next().getValue(User_Info.class);

                        if (pin.equals(user.getPin())){

                            dbOrder = FirebaseDatabase.getInstance().getReference("Orders").child(userKey).child(cusID);

                            moveRecord(dbCart, dbOrder);
                            transactions();
                            removeCart();
//                            removeCus();

//                            Toast.makeText(CartList.this, "Welcome "+user.getUserName(), Toast.LENGTH_SHORT).show();
                            b.dismiss();
                        } else {
                            Toast.makeText(CartList.this, "Wrong pin!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });
    }

    public void payment() {

        TextView title = new TextView(CartList.this);
        title.setText(String.format("Amount Due: ₱%.2f", totalAmt));
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(CartList.this);
        LayoutInflater inflater = LayoutInflater.from(CartList.this);
        final View dialogView = inflater.inflate(R.layout.payment, null);
        dialogBuilder.setView(dialogView);

        final EditText payment = (EditText) dialogView.findViewById(R.id.payment);
        final Button proceed = (Button) dialogView.findViewById(R.id.proceed);
        final Button cancel = (Button) dialogView.findViewById(R.id.cancel);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String paY = payment.getText().toString().trim();



                if (TextUtils.isEmpty(paY)){
                    Toast.makeText(CartList.this, "Enter Amount!", Toast.LENGTH_SHORT).show();
                    return;
                }
                pay = Double.parseDouble(payment.getText().toString().trim());

                if (pay < totalAmt){
                    Toast.makeText(CartList.this, "Insufficient Amount!", Toast.LENGTH_SHORT).show();
                } else {
                    change = pay - totalAmt;
                    inputPin();
                    b.dismiss();
                }

            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.dismiss();
            }
        });
    }
}
