package com.example.kenxhin23.goodbargain.model;

/**
 * Created by kenxhin23 on 7/15/2020.
 */

public class Category {

    private String id;
    private String category;


    public Category(){

    }

    public Category( String id, String category) {

        this.id = id;
        this.category = category;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getCat() {
        return category;
    }

    public void setCat(String category) {
        this.category = category;
    }
}
