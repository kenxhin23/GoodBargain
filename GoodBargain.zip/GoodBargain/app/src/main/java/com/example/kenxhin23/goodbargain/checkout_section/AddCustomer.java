package com.example.kenxhin23.goodbargain.checkout_section;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.CartAdapter;
import com.example.kenxhin23.goodbargain.adapters.CustomerAdapter;
import com.example.kenxhin23.goodbargain.model.Cart;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.navigation_fragment.CheckoutFragment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AddCustomer extends AppCompatActivity implements CustomerAdapter.OnItemClickListener {
    Context context = getApplication();
    private FirebaseAuth auth;
    ProgressDialog progressDialog;
    CustomerAdapter customerAdapter = null;
    List<Customer> list = new ArrayList<>();
    DatabaseReference databaseReference;
    SwipeRefreshLayout swipeRefresh;
    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_customer);
        setTitle("Customers");

        swipeRefresh = (SwipeRefreshLayout) findViewById(R.id.swipeCus);
        recyclerView = (RecyclerView) findViewById(R.id.recycleCus);

        LinearLayoutManager manager = new LinearLayoutManager(AddCustomer.this);
        recyclerView.setLayoutManager(manager);
        recyclerView.setHasFixedSize(true);

        customerAdapter = new CustomerAdapter(context, list);
        recyclerView.setAdapter(customerAdapter);
        customerAdapter.setOnItemClickListener(AddCustomer.this);

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Customer").child(userKey);

        result();

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                int color = getResources().getColor(R.color.colorPrimary);
                swipeRefresh.setColorSchemeColors(color);
                result();
                swipeRefresh.setRefreshing(false);
            }
        });


    }

    @Override
    public void onItemClick(int position) {
        final Customer customer = list.get(position);

    }

    public void result() {

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                list.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    Customer customer = postSnapshot.getValue(Customer.class);
                    list.add(customer);
                }
                customerAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.add_customer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.addCustomer:
                addCustomer();
                break;

        }
        return true;
    }

    public void addCustomer() {

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(AddCustomer.this);
        LayoutInflater inflater = LayoutInflater.from(AddCustomer.this);
        final View dialogView = inflater.inflate(R.layout.add_customer, null);
        dialogBuilder.setView(dialogView);

        final EditText cname = (EditText) dialogView.findViewById(R.id.cusName);
        final Button buttonAdd = (Button) dialogView.findViewById(R.id.btnAddCus);
        final Button buttonCancel = (Button) dialogView.findViewById(R.id.btnCancelCus);

        dialogBuilder.setTitle("New Customer");
        final AlertDialog b = dialogBuilder.create();
        b.show();

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String cusName = cname.getText().toString().trim();
                String cusID = databaseReference.push().getKey();

                if (TextUtils.isEmpty(cusName)) {
                    Toast.makeText(AddCustomer.this, "Enter Customer Name", Toast.LENGTH_SHORT).show();
                    return;
                }

                Customer customer = new Customer(
                        cusID,
                        cusName
                );
                databaseReference.child(cusID).setValue(customer)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(AddCustomer.this, "Saved", Toast.LENGTH_LONG).show();
                                b.dismiss();
                                finish();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.dismiss();
            }
        });
    }
}