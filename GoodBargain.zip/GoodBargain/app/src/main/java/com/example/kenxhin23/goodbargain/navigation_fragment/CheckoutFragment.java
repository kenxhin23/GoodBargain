package com.example.kenxhin23.goodbargain.navigation_fragment;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.CategoryAdapter;
import com.example.kenxhin23.goodbargain.adapters.DynamicAdapter;
import com.example.kenxhin23.goodbargain.adapters.FragmentsAdapter;
import com.example.kenxhin23.goodbargain.adapters.ProductAdapter;
import com.example.kenxhin23.goodbargain.adapters.ViewPagerAdapter;
import com.example.kenxhin23.goodbargain.checkout_section.AddCustomer;
import com.example.kenxhin23.goodbargain.checkout_section.CartList;
import com.example.kenxhin23.goodbargain.checkout_section.CategoryFragment;
import com.example.kenxhin23.goodbargain.checkout_section.ProductFragment;
import com.example.kenxhin23.goodbargain.model.Category;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.example.kenxhin23.goodbargain.product_section.AddCategory;
import com.example.kenxhin23.goodbargain.product_section.CategoriesFragment;
import com.example.kenxhin23.goodbargain.product_section.ItemFragment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kenxhin23 on 2/3/2020.
 */

public class CheckoutFragment extends Fragment {


    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;
    private FirebaseAuth auth;
    DatabaseReference databaseReference;
    ProgressDialog progressDialog;
    String name;
    Spinner spinner;
    List<Customer> list = new ArrayList<>();
    List<String> cusName = new ArrayList<String>();
    ArrayAdapter<String> dataAdapter;


    public CheckoutFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_checkout, container, false);
        tabLayout = (TabLayout)v.findViewById(R.id.tablelayout);
        viewPager = (ViewPager) v.findViewById(R.id.viewpager);

        adapter = new ViewPagerAdapter(getChildFragmentManager());

        adapter.AddFragment(new ProductFragment(), "Products");
        adapter.AddFragment(new CategoryFragment(), "By Categories");

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        return v;
    }
}
