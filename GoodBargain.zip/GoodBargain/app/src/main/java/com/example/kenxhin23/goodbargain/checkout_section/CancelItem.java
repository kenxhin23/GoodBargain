package com.example.kenxhin23.goodbargain.checkout_section;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.Cart;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CancelItem extends AppCompatActivity {

    TextView itemName, itemQty, itemAmount;
    ImageView showImageCart;
    Button btnCancel;
    String pid, userKey, url, pname, qty, stk, cat, desc, cusID, cartid, cus;
    double price, cost, amt, totalAmt;
    int newStk, Stk, Qty;
    private FirebaseAuth auth;
    Cart cart;
    DatabaseReference dbProduct, dbCart;
    Query qProduct, qCart;
    Context context = this;
    List<Cart> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_item);

        init();

        Intent i = getIntent();
        pid = i.getExtras().getString("pid");
        qty = i.getExtras().getString("qty");
        cusID = i.getExtras().getString("cusID");
        cartid = i.getExtras().getString("cartID");
        cus = i.getExtras().getString("cus");

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        userKey = store.getUid();
        dbCart = FirebaseDatabase.getInstance().getReference("Cart").child(userKey);
        dbProduct = FirebaseDatabase.getInstance().getReference("Products").child(userKey);

        qProduct = dbProduct.orderByChild("id").equalTo(pid);
        qProduct.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    ProductInfo productInfo = postSnapshot.getValue(ProductInfo.class);

                    Qty = Integer.parseInt(qty);

                    stk = productInfo.getStock();
                    cat = productInfo.getCategory();
                    price = productInfo.getPrice();
                    desc = productInfo.getDescription();
                    cost = productInfo.getCost();
                    url = productInfo.getImageUrl();
                    pname = productInfo.getItemName();

                    itemName.setText(pname);
                    amt = price * Qty;
                    itemQty.setText("Quantity: "+qty);
                    itemAmount.setText(String.format("Amount: %.2f", amt));
                    Glide.with(CancelItem.this).load(url).into(showImageCart);

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                Toast.makeText(CancelItem.this, cusID, Toast.LENGTH_SHORT).show();

                remove();

            }
        });

    }

    @Override
    public void onBackPressed()
    {
        Intent intent = new Intent(CancelItem.this, CartList.class);
        intent.putExtra("cusID", cusID);
        intent.putExtra("cname", cus);
        startActivity(intent);
        finish();

        super.onBackPressed();
    }

    public void remove() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(CancelItem.this);

        builder.setMessage("Are you sure?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                update();

                dbCart = FirebaseDatabase.getInstance().getReference("Cart").child(userKey).child(cusID);
                Query query = dbCart.orderByChild("id").equalTo(cartid);

                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            cart = ds.getValue(Cart.class);

                            ds.getRef().removeValue();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                Intent intent = new Intent(CancelItem.this, CartList.class);
                intent.putExtra("cusID", cusID);
                intent.putExtra("cname", cus);
                startActivity(intent);
                finish();
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                dialog.cancel();
            }
        });
        AlertDialog log = builder.create();
        log.show();
    }

    public void update() {

        Stk = Integer.parseInt(stk);
        Qty = Integer.parseInt(qty);
        newStk = Stk + Qty;

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        dbProduct = FirebaseDatabase.getInstance().getReference("Products").child(userKey).child(pid);

        ProductInfo product = new ProductInfo(
                pid,
                pname,
                price,
                cat,
                desc,
                cost,
                ""+newStk,
                url);
        dbProduct.setValue(product)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
//                        Toast.makeText(getApplicationContext(), "Item Cancelled!", Toast.LENGTH_LONG).show();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void init() {

        itemName = (TextView) findViewById(R.id.itemName);
        itemQty = (TextView) findViewById(R.id.itemQty);
        itemAmount = (TextView) findViewById(R.id.itemAmt);
        showImageCart = (ImageView) findViewById(R.id.showImageCart);
        btnCancel = (Button) findViewById(R.id.btnCancelItem);
    }
}