package com.example.kenxhin23.goodbargain.model;

/**
 * Created by kenxhin23 on 7/31/2020.
 */

public class Fragments {

    private String id;
    private String fragment;


    public Fragments(){

    }

    public Fragments( String id, String fragment) {

        this.id = id;
        this.fragment = fragment;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getFrag() {
        return fragment;
    }

    public void setFrag(String fragment) {
        this.fragment = fragment;
    }



}
