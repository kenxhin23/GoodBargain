package com.example.kenxhin23.goodbargain.customer_section;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.CartAdapter;
import com.example.kenxhin23.goodbargain.checkout_section.CartList;
import com.example.kenxhin23.goodbargain.model.Cart;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.example.kenxhin23.goodbargain.model.Store;
import com.example.kenxhin23.goodbargain.model.Transactions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Orders extends AppCompatActivity implements CartAdapter.OnItemClickListener {

    String cusID, cname, userKey, keys, stringtotal;
    SwipeRefreshLayout swipeRefresh;
    RecyclerView recyclerCart;
    DatabaseReference dbOrder, dbTrans, dbCus;
    CartAdapter cartAdapter = null;
    List<Cart> list = new ArrayList<>();
    private FirebaseAuth auth;
    TextView totalAmt, totalCost, totalDis, profit;
    double total, amt, cost, totalcost, totaldis, dis, Profit, camt, camount;
    String qty;
    Button testing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);

        Intent i = getIntent();
        cusID = i.getExtras().getString("cusID");
        cname = i.getExtras().getString("cname");
        setTitle("Orders: "+cname);

        init();
        LinearLayoutManager manager = new LinearLayoutManager(Orders.this);
        recyclerCart.setLayoutManager(manager);
        recyclerCart.setHasFixedSize(true);

        cartAdapter = new CartAdapter(Orders.this, list);
        recyclerCart.setAdapter(cartAdapter);
        cartAdapter.setOnItemClickListener(Orders.this);

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        userKey = store.getUid();
        dbOrder = FirebaseDatabase.getInstance().getReference("Orders").child(userKey).child(cusID);
        dbOrder.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot datas: dataSnapshot.getChildren()){
                    keys = datas.getKey();

//                    Toast.makeText(Orders.this, keys, Toast.LENGTH_SHORT).show();

                    dbOrder = FirebaseDatabase.getInstance().getReference("Orders").child(userKey).child(cusID).child(keys);
                    dbOrder.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
//                            list.clear();
                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                                Cart cart = postSnapshot.getValue(Cart.class);

                                list.add(cart);
                                amt = cart.getAmount();
                                camt = cart.getCamount();
                                total += amt;
                                totalcost += camt;

                                totalAmt.setText(String.format("₱%.2f", total));
                                totalCost.setText(String.format("₱%.2f" , totalcost));

                            }
                            cartAdapter.notifyDataSetChanged();
                        }
                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });


                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        dbTrans = FirebaseDatabase.getInstance().getReference("Transactions").child(userKey);
        Query q = dbTrans.orderByChild("custID").equalTo(cusID);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()){

                    Transactions trans = ds.getValue(Transactions.class);

                    dis = trans.getDiscount();
                    totaldis += dis;

                    totalDis.setText(String.format("₱%.2f", totaldis));

                }


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                int color = getResources().getColor(R.color.colorPrimary);
                swipeRefresh.setColorSchemeColors(color);
                swipeRefresh.setRefreshing(false);
            }
        });
    }

    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.delete_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.delete:

                final AlertDialog.Builder builder = new AlertDialog.Builder(Orders.this);

                builder.setTitle("Delete Customer?");

                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        removeCus();
                        removeOrder();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog log = builder.create();
                log.show();

                break;

        }
        return true;
    }


    public void init() {

        swipeRefresh = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh);
        recyclerCart = (RecyclerView) findViewById(R.id.recyclerOrder);
        totalAmt = (TextView) findViewById(R.id.totalAmt);
        totalCost = (TextView) findViewById(R.id.totalCost);
        totalDis = (TextView) findViewById(R.id.totalDis);
        profit = (TextView) findViewById(R.id.profit);

    }

    @Override
    public void onItemClick(int position) {

    }

    public void removeCus() {

        dbCus = FirebaseDatabase.getInstance().getReference("Customer").child(userKey).child(cusID);
        dbCus.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    ds.getRef().removeValue();
                }

                finish();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void removeOrder() {

        dbCus = FirebaseDatabase.getInstance().getReference("Orders").child(userKey).child(cusID);
        dbCus.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    ds.getRef().removeValue();
                }

                finish();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

}