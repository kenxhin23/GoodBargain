package com.example.kenxhin23.goodbargain.navigation_fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.model.Category;
import com.example.kenxhin23.goodbargain.product_section.AddCategory;
import com.example.kenxhin23.goodbargain.product_section.AddItem;
import com.example.kenxhin23.goodbargain.product_section.CategoriesFragment;
import com.example.kenxhin23.goodbargain.product_section.CategoryList;
import com.example.kenxhin23.goodbargain.product_section.ItemFragment;
import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.ViewPagerAdapter;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by kenxhin23 on 2/3/2020.
 */

public class ProductsFragment extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;
    DatabaseReference dbCat;
    private FirebaseAuth auth;
    public ProductsFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_products, container, false);
        tabLayout = (TabLayout)v.findViewById(R.id.tablelayout);
        viewPager = (ViewPager) v.findViewById(R.id.viewpager);

        adapter = new ViewPagerAdapter(getChildFragmentManager());

        adapter.AddFragment(new ItemFragment(), "Products");
        adapter.AddFragment(new CategoriesFragment(), "Categories");

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        dbCat = FirebaseDatabase.getInstance().getReference("Category").child(userKey);
        return v;

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        MenuInflater in = getActivity().getMenuInflater();
        in.inflate(R.menu.add_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.addUser:
                addnew();
                break;
        }
        return true;
    }

    public void addnew(){

        TextView title = new TextView(getContext());
        title.setText("Add New");
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = LayoutInflater.from(getContext());
        final View dialogView = inflater.inflate(R.layout.add_cat, null);
        dialogBuilder.setView(dialogView);

        final Button btnP = (Button) dialogView.findViewById(R.id.btnAddProduct);
        final Button btnC = (Button) dialogView.findViewById(R.id.btnAddCatergory);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), AddItem.class);
                startActivity(i);
                b.dismiss();
            }
        });
        btnC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addCategory();
                b.dismiss();
            }
        });
    }

    public void addCategory(){

        TextView title = new TextView(getContext());
        title.setText("New Category");
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = LayoutInflater.from(getContext());
        final View dialogView = inflater.inflate(R.layout.add_category, null);
        dialogBuilder.setView(dialogView);

        final EditText editCat = (EditText) dialogView.findViewById(R.id.editCat);
        final Button btnCat = (Button) dialogView.findViewById(R.id.btnCat);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String category =  editCat.getText().toString().trim();
                String id = dbCat.push().getKey();

                if (TextUtils.isEmpty(category)) {
                    Toast.makeText(getContext(), "Enter Catergory!", Toast.LENGTH_SHORT).show();
                    return;
                }

                Category cat = new Category(
                        id,
                        category
                );
                dbCat.child(id).setValue(cat)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {

                                Toast.makeText(getContext(), "Saved", Toast.LENGTH_LONG).show();


                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                b.dismiss();
            }
        });
    }
}
