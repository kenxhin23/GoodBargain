package com.example.kenxhin23.goodbargain;

import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.Store;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Register extends AppCompatActivity {

    private TextInputLayout textInputLayoutStorename;
    private TextInputLayout textInputLayoutOname;
    private TextInputLayout textInputLayoutEmail;
    private TextInputLayout textInputLayoutPassword;
    private TextInputLayout textInputLayoutConfirmPassword;

    private TextInputEditText textInputEditStoreName;
    private TextInputEditText textInputEditTextOname;
    private TextInputEditText textInputEditTextEmail;
    private TextInputEditText textInputEditTextPassword;
    private TextInputEditText textInputEditTextConfirmPassword;

    private AppCompatButton regLink;
    private AppCompatTextView logLink;
    private ProgressBar progressBar;

    private FirebaseAuth auth;

    Store store;
    DatabaseReference db;
    long id;
    String sid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorProgress)));

        initViews();

        logLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        store = new Store();
        db = FirebaseDatabase.getInstance().getReference().child("Store");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    id = (dataSnapshot.getChildrenCount());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        regLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String sname =  textInputEditStoreName.getText().toString().trim();
                final String oname = textInputEditTextOname.getText().toString().trim();
                final String email = textInputEditTextEmail.getText().toString().trim();
                final String pass = textInputEditTextPassword.getText().toString().trim();
                String cpass = textInputEditTextConfirmPassword.getText().toString().trim();

                if (TextUtils.isEmpty(sname)) {
                    textInputLayoutStorename.setError(getString(R.string.error_message_sname));
                    return;
                }
                if (TextUtils.isEmpty(oname)) {
                    textInputLayoutOname.setError(getString(R.string.error_message_oname));
                    return;
                }
                if (TextUtils.isEmpty(email)) {
                    textInputLayoutEmail.setError(getString(R.string.error_message_email));
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    textInputLayoutEmail.setError(getString(R.string.error_message_invalid_email));
                    return;
                }
                if (TextUtils.isEmpty(pass)) {
                    textInputLayoutPassword.setError(getString(R.string.error_message_password));
                    return;
                }
                if (pass.length() < 8) {
                    textInputLayoutPassword.setError(getString(R.string.error_password_length));
                    return;
                }
                if (TextUtils.isEmpty(cpass)) {
                    textInputLayoutConfirmPassword.setError(getString(R.string.error_message_cpassword));
                    return;
                }
                if (!pass.contentEquals(cpass)){
                    Toast.makeText(getApplicationContext(), "Password did not match!", Toast.LENGTH_SHORT).show();
                    return;
                }
                sid = db.push().getKey();
                progressBar.setVisibility(View.VISIBLE);
                auth.createUserWithEmailAndPassword(email, pass)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    Store store = new Store(
                                            sid,
                                            sname,
                                            oname,
                                            email,
                                            pass
                                    );
                                    FirebaseDatabase.getInstance().getReference("Store")
//                                    String.valueOf("StoreID_"+id++)
                                            .child(sid)
                                            .setValue(store).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            progressBar.setVisibility(View.GONE);
                                            if (task.isSuccessful()){
                                                Toast.makeText(getApplicationContext(), "Registration Success!", Toast.LENGTH_LONG).show();
                                            } else {
                                                Toast.makeText(getApplicationContext(), "Check your connection!", Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                } else {
                                    progressBar.setVisibility(View.GONE);
                                    Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    }
                });
    }

    private void initViews() {

        auth = FirebaseAuth.getInstance();
        textInputLayoutStorename = (TextInputLayout) findViewById(R.id.textInputLayoutStoreName);
        textInputLayoutOname = (TextInputLayout) findViewById(R.id.textInputLayoutOname);
        textInputLayoutEmail = (TextInputLayout) findViewById(R.id.textInputLayoutEmail);
        textInputLayoutPassword = (TextInputLayout) findViewById(R.id.textInputLayoutPassword);
        textInputLayoutConfirmPassword = (TextInputLayout) findViewById(R.id.textInputLayoutConfirmPassword);


        textInputEditStoreName = (TextInputEditText) findViewById(R.id.textInputEditStoreName);
        textInputEditTextOname = (TextInputEditText) findViewById(R.id.textInputEditTextOname);
        textInputEditTextEmail = (TextInputEditText) findViewById(R.id.textInputEditTextEmail);
        textInputEditTextPassword = (TextInputEditText) findViewById(R.id.textInputEditTextPassword);
        textInputEditTextConfirmPassword = (TextInputEditText) findViewById(R.id.textInputEditTextConfirmPassword);

        regLink = (AppCompatButton) findViewById(R.id.regLink);

        logLink = (AppCompatTextView) findViewById(R.id.logLink);

        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        progressBar.setVisibility(View.GONE);


    }

    @Override
    protected void onStart() {
        super.onStart();

        if(auth.getCurrentUser() != null){

        }
    }
}
