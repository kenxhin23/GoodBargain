package com.example.kenxhin23.goodbargain.adapters;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kenxhin23 on 7/31/2020.
 */

public class DynamicAdapter extends FragmentPagerAdapter {

    private final List<Fragment> lstFragment = new ArrayList<>();
    private List<String> lstTitles = new ArrayList<>();
    Context context;

    public DynamicAdapter (FragmentManager fm, ArrayList<String> lstTitles){
        super(fm);
        this.lstTitles = lstTitles;
    }
    @Override
    public Fragment getItem(int position) {
        return lstFragment.get(position);
    }

    @Override
    public int getCount() {
        return lstFragment.size();
    }

    public void addFrag(Fragment fragment, String title) {
        lstFragment.add(fragment);
        lstTitles.add(title);

    }

    @Override
    public CharSequence getPageTitle(int position) {
        return lstTitles.get(position);
    }

}
