package com.example.kenxhin23.goodbargain.adapters;

import android.app.Dialog;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.model.Transactions;

import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder>  {

    Context context;
    List<Transactions> TransactionList;
    OnItemClickListener transListener;

    public interface OnItemClickListener{
        void onItemClick (int position);

        @Deprecated
        Dialog onCreateDialog(int id);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        transListener = listener;
    }

    public TransactionAdapter(Context context, List<Transactions> TempList) {
        this.context = context;
        this.TransactionList = TempList;
    }

    @Override
    public TransactionAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_trans, parent, false);
        TransactionAdapter.ViewHolder viewHolder = new TransactionAdapter.ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(TransactionAdapter.ViewHolder holder, int position) {

        Transactions trans = TransactionList.get(position);
        holder.date.setText(trans.getDate());
        holder.totalSales.setText(String.format("%.2f", trans.getAmount()));
        holder.totalCost.setText(String.format("%.2f", trans.getCamount()));
        holder.totalDiscount.setText(String.format("%.2f", trans.getDiscount()));


    }

    @Override
    public int getItemCount() {
        return TransactionList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView date, totalSales, totalCost, totalDiscount;

        public ViewHolder(View view) {
            super(view);

            date = (TextView) view.findViewById(R.id.date);
            totalSales = (TextView) view.findViewById(R.id.totalSales);
            totalCost = (TextView) view.findViewById(R.id.totalCost);
            totalDiscount = (TextView) view.findViewById(R.id.totalDiscount);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (transListener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            transListener.onItemClick(position);
                        }
                    }
                }
            });

        }
    }
}
