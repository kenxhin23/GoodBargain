package com.example.kenxhin23.goodbargain.product_section;

import android.app.ProgressDialog;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.Category;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class AddCategory extends AppCompatActivity {

    private Button saveButton;
    private EditText categoryName;
    private TextInputLayout layoutAddCat;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
    ProgressDialog progressDialog;
    FirebaseDatabase db;
    StorageReference storageReference;
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_category);
        setTitle("New Category");

        storageReference = FirebaseStorage.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Category").child(userKey);

        categoryName = (EditText) findViewById(R.id.EditAddCategory);
        layoutAddCat = (TextInputLayout) findViewById(R.id.layoutAddCat);
        saveButton = (Button) findViewById(R.id.saveCat);

        progressDialog = new ProgressDialog(AddCategory.this);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCategory();

            }
        });

    }

    public void addCategory(){


        String category =  categoryName.getText().toString().trim();
        String id = databaseReference.push().getKey();

        if (TextUtils.isEmpty(category)) {
            layoutAddCat.setError("Enter Category");
            return;
        }
        progressDialog.setTitle("Saving...");
        progressDialog.show();

        Category cat = new Category(
                id,
                category
        );
        databaseReference.child(id).setValue(cat)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
                        progressDialog.dismiss();
                        finish();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();

                        Toast.makeText(AddCategory.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
