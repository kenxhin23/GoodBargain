package com.example.kenxhin23.goodbargain.product_section;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.CategoryAdapter;
import com.example.kenxhin23.goodbargain.checkout_section.CartList;
import com.example.kenxhin23.goodbargain.model.Category;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CategoryList extends AppCompatActivity implements CategoryAdapter.OnItemClickListener {

    Context context = getApplication();

    DatabaseReference databaseReference;
    RecyclerView recyclerCat;
    private FirebaseAuth auth;
    ProgressDialog progressDialog;
    CategoryAdapter cAdapter = null;
    List<Category> list1 = new ArrayList<>();
    ImageView imageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_list);
        setTitle("Categories");

        recyclerCat = (RecyclerView) findViewById(R.id.catRecycleView);

        LinearLayoutManager manager = new LinearLayoutManager(context);
        recyclerCat.setLayoutManager(manager);
        recyclerCat.setHasFixedSize(true);

        progressDialog = new ProgressDialog(CategoryList.this);

        cAdapter = new CategoryAdapter(context, list1);
        recyclerCat.setAdapter(cAdapter);


        cAdapter.setOnItemClickListener(CategoryList.this);


        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Category").child(userKey);



        result();

//        imageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                addCategory();
//            }
//        });

    }

    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.add_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.addUser:
                addCategory();
                break;

        }
        return true;
    }

    @Override
    public void onItemClick(int position) {

        final Category category = list1.get(position);
        String cat = category.getCat();

        Intent i = new Intent();
        i.putExtra("category", cat);
        setResult(RESULT_OK,i);
        finish();

    }

    public void result(){

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                list1.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    Category category = postSnapshot.getValue(Category.class);

                    list1.add(category);
                }
                cAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }

    public void addCategory(){

        TextView title = new TextView(CategoryList.this);
        title.setText("New Category");
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(CategoryList.this);
        LayoutInflater inflater = LayoutInflater.from(CategoryList.this);
        final View dialogView = inflater.inflate(R.layout.add_category, null);
        dialogBuilder.setView(dialogView);

        final EditText editCat = (EditText) dialogView.findViewById(R.id.editCat);
        final Button btnCat = (Button) dialogView.findViewById(R.id.btnCat);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String category =  editCat.getText().toString().trim();
                String id = databaseReference.push().getKey();

                if (TextUtils.isEmpty(category)) {
                    Toast.makeText(CategoryList.this, "Enter Catergory!", Toast.LENGTH_SHORT).show();
                    return;
                }
                progressDialog.setTitle("Saving...");
                progressDialog.show();

                Category cat = new Category(
                        id,
                        category
                );
                databaseReference.child(id).setValue(cat)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {

                                Toast.makeText(CategoryList.this, "Saved", Toast.LENGTH_LONG).show();
                                progressDialog.dismiss();


                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                progressDialog.dismiss();

                                Toast.makeText(CategoryList.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                result();
                b.dismiss();
            }
        });
    }
}
