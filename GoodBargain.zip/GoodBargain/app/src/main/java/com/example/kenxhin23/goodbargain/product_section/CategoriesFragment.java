package com.example.kenxhin23.goodbargain.product_section;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.CategoryAdapter;
import com.example.kenxhin23.goodbargain.adapters.ProductAdapter;
import com.example.kenxhin23.goodbargain.model.Category;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kenxhin23 on 2/3/2020.
 */

public class CategoriesFragment extends Fragment implements CategoryAdapter.OnItemClickListener {

    DatabaseReference databaseReference;
    RecyclerView recyclerCat;
    private FirebaseAuth auth;
    ProgressDialog progressDialog;
    CategoryAdapter cAdapter = null;
    List<Category> list1 = new ArrayList<>();
    ImageView imageView;
    View v;
    SearchView searchView;
    String id, cat;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.cat_list, container, false);
        return v;

    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerCat = (RecyclerView) view.findViewById(R.id.catRecycleView);
        searchView = (SearchView) view.findViewById(R.id.searchCat);

        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        recyclerCat.setLayoutManager(manager);
        recyclerCat.setHasFixedSize(true);

        progressDialog = new ProgressDialog(getActivity());

        cAdapter = new CategoryAdapter(getContext(), list1);
        recyclerCat.setAdapter(cAdapter);
        cAdapter.setOnItemClickListener(CategoriesFragment.this);


        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Category").child(userKey);

        result();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                firebaseSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {


                if(!newText.isEmpty()){
                    // call seearch method if user starts typing
                    firebaseSearch(newText);;
                }

                //else
                else{
                    // set TextField empty
                    firebaseSearch("");
                }
                return true;
            }
        });

    }


    @Override
    public void onItemClick(int position) {

        final Category category = list1.get(position);
        id = category.getID();
        cat = category.getCat();

        deleteCat();
    }

    private void firebaseSearch(String searchText) {

        //convert string entered in SearchView to lowercase
        String query = searchText.toLowerCase();

        Query q = databaseReference.orderByChild("cat").startAt(searchText).endAt(searchText + "\uf8ff");
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if(dataSnapshot.hasChildren()) {

                    //clears the arrayList
                    list1.clear();

                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                        Category category = snapshot.getValue(Category.class);

                        list1.add(category);

                        //adds the rooms searched to the arrayList

                    }
//                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
//                    ProductInfo productInfo = postSnapshot.getValue(ProductInfo.class);
//                    list.add(productInfo);
//                }
                }
                cAdapter = new CategoryAdapter(getContext(), list1);
                recyclerCat.setAdapter(cAdapter);
                cAdapter.setOnItemClickListener(CategoriesFragment.this);
                cAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void result(){

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                list1.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    Category category = postSnapshot.getValue(Category.class);

                    list1.add(category);
                }
                cAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }

    public void deleteCat() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        builder.setTitle("Delete Category");
        builder.setMessage("Are you sure?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                delete();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog log = builder.create();
        log.show();
    }

    public void delete(){

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Category").child(userKey).child(id);
        databaseReference.removeValue();
        Toast.makeText(getContext(), "Category Deleted", Toast.LENGTH_LONG).show();

    }
}
