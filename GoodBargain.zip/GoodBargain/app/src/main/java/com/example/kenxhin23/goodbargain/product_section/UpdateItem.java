package com.example.kenxhin23.goodbargain.product_section;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.design.widget.TextInputLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.ViewPagerAdapter;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Text;

public class UpdateItem extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private TextInputLayout layoutPname, layoutPrice, layoutDesc, layoutOprice, layoutQty;
    private ImageView showImageView;
    private EditText editProductName;
    private EditText editPrice;
    private TextView editCategory;
    private EditText editDescription;
    private EditText editCost;
    private EditText editStock;
    Context context = this;
    private Button updateButton;

    private FirebaseAuth auth;

    ProgressDialog progressDialog;
    StorageReference storageReference;
    DatabaseReference databaseReference;
    private final static int MY_REQUEST_CODE = 1;

    String id, name, category, description, stock, url;
    double price, cost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_item);

        init();

        storageReference = FirebaseStorage.getInstance().getReference();

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Products").child(userKey);

        Intent i = getIntent();
        id = i.getExtras().getString("id");
        name = i.getExtras().getString("name");
        price = i.getExtras().getDouble("price");
        category = i.getExtras().getString("category");
        description = i.getExtras().getString("description");
        cost = i.getExtras().getDouble("cost");
        stock = i.getExtras().getString("stock");
        url = i.getExtras().getString("url");

        setTitle(""+ name);

        editProductName.setText(""+name);
        editPrice.setText(String.format("%.2f",price));
        editCategory.setText(""+category);
        editDescription.setText(""+description);
        editCost.setText(String.format("%.2f",cost));
        editStock.setText(""+stock);
        Glide.with(context).load(url).into(showImageView);

        progressDialog = new ProgressDialog(UpdateItem.this);

        editCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                categoryList();
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                update();


            }
        });

    }

    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.delete_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.delete:

                final AlertDialog.Builder builder = new AlertDialog.Builder(context);

                builder.setTitle("Delete Product");
                builder.setMessage("Are you sure? This action cannot be undone.");

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        delete();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog log = builder.create();
                log.show();

                break;

        }
        return true;
    }

    @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {

            super.onActivityResult(requestCode, resultCode, data);

            if (resultCode == Activity.RESULT_OK) {
                if (requestCode == MY_REQUEST_CODE) {
                    if (data != null)
                        editCategory.setText(data.getStringExtra("category"));
                }
            }
    }

    public void init(){

        tabLayout = (TabLayout)findViewById(R.id.tablayout);
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        editProductName = (EditText) findViewById(R.id.EditProductName);
        editPrice = (EditText) findViewById(R.id.EditPrice);
        editDescription = (EditText) findViewById(R.id.EditDescription);
        editCost = (EditText) findViewById(R.id.EditCost);
        editStock = (EditText) findViewById(R.id.EditStock);
        layoutPname = (TextInputLayout) findViewById(R.id.layoutPname);
        layoutPrice = (TextInputLayout) findViewById(R.id.layoutPrice);
        layoutDesc = (TextInputLayout) findViewById(R.id.layoutDescription);
        layoutOprice = (TextInputLayout) findViewById(R.id.layoutCost);
        layoutQty = (TextInputLayout) findViewById(R.id.layoutQty);
        showImageView = (ImageView) findViewById(R.id.showImageView);
        editCategory = (TextView) findViewById(R.id.EditCategory);
        updateButton = (Button) findViewById(R.id.updateButton);

    }

    public void update(){

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Products").child(userKey).child(id);

        final double price = parseDouble(editPrice.getText().toString().trim());
        final double cost = parseDouble(editCost.getText().toString().trim());
        final String name =  editProductName.getText().toString().trim();
        final String category =  editCategory.getText().toString().trim();
        final String description =  editDescription.getText().toString().trim();
        final String stock =  editStock.getText().toString().trim();
        final String pid = id;


        if (TextUtils.isEmpty(name)) {
            layoutPname.setError("Enter Name");
            return;
        }
        if (editPrice.getText().toString().trim().isEmpty()) {
            layoutPrice.setError("Enter Price");
            return;
        }
        if (editCategory.getText().equals("Category")) {
            editCategory.setError("Select Category");
            return;
        }
        if (TextUtils.isEmpty(description)) {
            layoutDesc.setError("Enter Description");
            return;
        }
        if (editCost.getText().toString().trim().isEmpty()) {
            layoutOprice.setError("Enter Original Price");
            return;
        }
        if (TextUtils.isEmpty(stock)) {
            layoutQty.setError("Enter Quantity");
            return;
        }
        if (price <= cost) {
//                layoutCost.setError("Value must be lower than Price");
            Toast.makeText(this, "Original Price must not be equal or greater than Price", Toast.LENGTH_SHORT).show();
            return;
        }
        progressDialog.setTitle("Updating...");
            progressDialog.show();

            ProductInfo product = new ProductInfo(
                    pid,
                    name,
                    price,
                    category,
                    description,
                    cost,
                    stock,
                    url);
            databaseReference.setValue(product)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                            progressDialog.dismiss();
                            finish();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();

                            Toast.makeText(UpdateItem.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
    }

    public void delete(){

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Products").child(userKey).child(id);

        databaseReference.removeValue();

        Toast.makeText(getApplicationContext(), "Item Deleted", Toast.LENGTH_LONG).show();
        finish();
    }

    public void categoryList(){

        Intent i = new Intent(UpdateItem.this, CategoryList.class);
        startActivityForResult(i, MY_REQUEST_CODE);

    }

    private double parseDouble(String s){
        if(s == null || s.isEmpty())
            return 0.0;
        else
            return Double.parseDouble(s);
    }

}
