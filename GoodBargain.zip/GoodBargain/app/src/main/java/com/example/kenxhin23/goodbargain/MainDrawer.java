package com.example.kenxhin23.goodbargain;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.checkout_section.CancelItem;
import com.example.kenxhin23.goodbargain.checkout_section.CartList;
import com.example.kenxhin23.goodbargain.model.Cart;
import com.example.kenxhin23.goodbargain.model.Store;
import com.example.kenxhin23.goodbargain.navigation_fragment.AdminFragment;
import com.example.kenxhin23.goodbargain.navigation_fragment.CheckoutFragment;
import com.example.kenxhin23.goodbargain.navigation_fragment.ProductsFragment;
import com.example.kenxhin23.goodbargain.navigation_fragment.CustomersFragment;
import com.example.kenxhin23.goodbargain.navigation_fragment.TransactionsFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainDrawer extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private DrawerLayout drawer;
    DatabaseReference databaseReference;
    private FirebaseAuth.AuthStateListener authListener;
    private FirebaseAuth auth;
    FirebaseUser firebaseUser;

    private Context context = this;

    TextView storeName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_drawer);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerLayout = navigationView.getHeaderView(0);
        storeName = (TextView) headerLayout.findViewById(R.id.storeName);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        auth = FirebaseAuth.getInstance();

        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getEmail();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Store");
        databaseReference.orderByChild("email").equalTo(userKey).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Store store = dataSnapshot.getChildren().iterator().next().getValue(Store.class);
                storeName.setText(store.getStoreName());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    // user auth state is changed - user is null
                    // launch login activity
                    startActivity(new Intent(MainDrawer.this, Login.class));
                    finish();
                }
            }
        };




        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        drawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        toggle.syncState();

        if (savedInstanceState == null){
            getSupportActionBar().setTitle("Checkout");
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    new CheckoutFragment()).commit();
            navigationView.setCheckedItem(R.id.checkout);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch(item.getItemId()){
            case R.id.checkout:
                getSupportActionBar().setTitle("Checkout");
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new CheckoutFragment()).commit();
                break;
            case R.id.products:
                productFragment();
//                getSupportActionBar().setTitle("Products");
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
//                        new ProductsFragment()).commit();
                break;
            case R.id.transactions:
                transactionFragment();
//                getSupportActionBar().setTitle("Transactions");
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
//                        new TransactionsFragment()).commit();
                break;
            case R.id.customers:
                customersFragment();
//                getSupportActionBar().setTitle("Customers");
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
//                        new CustomersFragment()).commit();
                break;
            case R.id.admin:
                adminFragment();
//                getSupportActionBar().setTitle("Admin");
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
//                        new AdminFragment()).commit();
                break;
            case R.id.logout:
                signOut();
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        } else {

            final AlertDialog.Builder builder = new AlertDialog.Builder(MainDrawer.this);
            builder.setMessage("Are you sure to exit?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });

            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int i) {
                    dialog.cancel();
                }
            });
            AlertDialog log = builder.create();
            log.show();

        }
    }

    public void signOut() {
        auth.signOut();
    }

    public void adminFragment(){

        TextView title = new TextView(MainDrawer.this);
        title.setText("Verification");
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainDrawer.this);
        LayoutInflater inflater = LayoutInflater.from(MainDrawer.this);
        final View dialogView = inflater.inflate(R.layout.admin_password, null);
        dialogBuilder.setView(dialogView);

        final EditText password = (EditText) dialogView.findViewById(R.id.adminPass);
        final Button btnOk = (Button) dialogView.findViewById(R.id.adminOk);
//        final Button btnCancel = (Button) dialogView.findViewById(R.id.adminCancel);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String pass = password.getText().toString().trim();

                if (TextUtils.isEmpty(pass)){
                    Toast.makeText(context, "Enter Password!", Toast.LENGTH_SHORT).show();
                    return;
                }
                FirebaseUser user = auth.getCurrentUser();
                final String userKey = user.getEmail();
                databaseReference = FirebaseDatabase.getInstance().getReference().child("Store");
                databaseReference.orderByChild("email").equalTo(userKey).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Store store = dataSnapshot.getChildren().iterator().next().getValue(Store.class);

                       if (pass.equals(store.getPassword())){
                           getSupportActionBar().setTitle("Admin");
                           getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                   new AdminFragment()).commit();

                           Toast.makeText(context, "Welcome "+store.getOwnerName(), Toast.LENGTH_SHORT).show();
                           b.dismiss();
                       } else {
                           Toast.makeText(context, "Access Denied!", Toast.LENGTH_SHORT).show();
                       }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });

//        btnCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                b.dismiss();
//            }
//        });
    }

    public void customersFragment() {

        TextView title = new TextView(MainDrawer.this);
        title.setText("Verification");
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainDrawer.this);
        LayoutInflater inflater = LayoutInflater.from(MainDrawer.this);
        final View dialogView = inflater.inflate(R.layout.admin_password, null);
        dialogBuilder.setView(dialogView);

        final EditText password = (EditText) dialogView.findViewById(R.id.adminPass);
        final Button btnOk = (Button) dialogView.findViewById(R.id.adminOk);
//        final Button btnCancel = (Button) dialogView.findViewById(R.id.adminCancel);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String pass = password.getText().toString().trim();

                if (TextUtils.isEmpty(pass)){
                    Toast.makeText(context, "Enter Password!", Toast.LENGTH_SHORT).show();
                    return;
                }
                FirebaseUser user = auth.getCurrentUser();
                final String userKey = user.getEmail();
                databaseReference = FirebaseDatabase.getInstance().getReference().child("Store");
                databaseReference.orderByChild("email").equalTo(userKey).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Store store = dataSnapshot.getChildren().iterator().next().getValue(Store.class);

                        if (pass.equals(store.getPassword())){
                            getSupportActionBar().setTitle("Customers");
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                    new CustomersFragment()).commit();

//                            Toast.makeText(context, "Welcome "+store.getOwnerName(), Toast.LENGTH_SHORT).show();
                            b.dismiss();
                        } else {
                            Toast.makeText(context, "Access Denied!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });

//        btnCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                b.dismiss();
//            }
//        });
    }

    public void productFragment() {

        TextView title = new TextView(MainDrawer.this);
        title.setText("Verification");
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainDrawer.this);
        LayoutInflater inflater = LayoutInflater.from(MainDrawer.this);
        final View dialogView = inflater.inflate(R.layout.admin_password, null);
        dialogBuilder.setView(dialogView);

        final EditText password = (EditText) dialogView.findViewById(R.id.adminPass);
        final Button btnOk = (Button) dialogView.findViewById(R.id.adminOk);
//        final Button btnCancel = (Button) dialogView.findViewById(R.id.adminCancel);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String pass = password.getText().toString().trim();

                if (TextUtils.isEmpty(pass)){
                    Toast.makeText(context, "Enter Password!", Toast.LENGTH_SHORT).show();
                    return;
                }
                FirebaseUser user = auth.getCurrentUser();
                final String userKey = user.getEmail();
                databaseReference = FirebaseDatabase.getInstance().getReference().child("Store");
                databaseReference.orderByChild("email").equalTo(userKey).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Store store = dataSnapshot.getChildren().iterator().next().getValue(Store.class);

                        if (pass.equals(store.getPassword())){
                            getSupportActionBar().setTitle("Products");
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                    new ProductsFragment()).commit();

//                            Toast.makeText(context, "Welcome "+store.getOwnerName(), Toast.LENGTH_SHORT).show();
                            b.dismiss();
                        } else {
                            Toast.makeText(context, "Access Denied!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });

//        btnCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                b.dismiss();
//            }
//        });
    }

    public void transactionFragment() {

        TextView title = new TextView(MainDrawer.this);
        title.setText("Verification");
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainDrawer.this);
        LayoutInflater inflater = LayoutInflater.from(MainDrawer.this);
        final View dialogView = inflater.inflate(R.layout.admin_password, null);
        dialogBuilder.setView(dialogView);

        final EditText password = (EditText) dialogView.findViewById(R.id.adminPass);
        final Button btnOk = (Button) dialogView.findViewById(R.id.adminOk);
//        final Button btnCancel = (Button) dialogView.findViewById(R.id.adminCancel);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String pass = password.getText().toString().trim();

                if (TextUtils.isEmpty(pass)){
                    Toast.makeText(context, "Enter Password!", Toast.LENGTH_SHORT).show();
                    return;
                }
                FirebaseUser user = auth.getCurrentUser();
                final String userKey = user.getEmail();
                databaseReference = FirebaseDatabase.getInstance().getReference().child("Store");
                databaseReference.orderByChild("email").equalTo(userKey).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Store store = dataSnapshot.getChildren().iterator().next().getValue(Store.class);

                        if (pass.equals(store.getPassword())){
                            getSupportActionBar().setTitle("Transactions");
                            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                    new TransactionsFragment()).commit();

//                            Toast.makeText(context, "Welcome "+store.getOwnerName(), Toast.LENGTH_SHORT).show();
                            b.dismiss();
                        } else {
                            Toast.makeText(context, "Access Denied!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });

//        btnCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                b.dismiss();
//            }
//        });
    }

    @Override
    public void onStart() {
        super.onStart();
        auth.addAuthStateListener(authListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (authListener != null) {
            auth.removeAuthStateListener(authListener);
        }
    }
}
