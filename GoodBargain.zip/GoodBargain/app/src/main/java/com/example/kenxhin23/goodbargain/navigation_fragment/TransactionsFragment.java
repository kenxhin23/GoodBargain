package com.example.kenxhin23.goodbargain.navigation_fragment;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.CustomerAdapter;
import com.example.kenxhin23.goodbargain.adapters.TransactionAdapter;
import com.example.kenxhin23.goodbargain.admin_section.AddUsers;
import com.example.kenxhin23.goodbargain.model.Cart;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.model.Transactions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Created by kenxhin23 on 2/3/2020.
 */

public class TransactionsFragment extends Fragment implements TransactionAdapter.OnItemClickListener {

    DatabaseReference dbTrans, dbCus;
    RecyclerView recyclerView;
    SwipeRefreshLayout swipeRefresh;
    ProgressDialog progressDialog;
    private FirebaseAuth auth;
    TransactionAdapter transAdapter;
    List<Transactions> list = new ArrayList<>();
    View v;
    final Calendar myCalendar= Calendar.getInstance();
    private int year;
    private int month;
    private int day;
    DatePickerDialog  StartTime;
    Calendar newCalendar;
    TextView totalSales, totalCost, totalDiscount, profit;
    double ts, tc, td, p, totalS, totalC, totalD, P;

    String userKey, cusID, keys, date;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.transaction_list, container,false);
        return v;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        swipeRefresh = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefresh);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycleView);
        totalSales = (TextView) view.findViewById(R.id.totalSales);
        totalCost = (TextView) view.findViewById(R.id.totalCost);
        totalDiscount = (TextView) view.findViewById(R.id.totalDiscount);
        profit = (TextView) view.findViewById(R.id.profit);


        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(manager);
        recyclerView.setHasFixedSize(true);

        progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        transAdapter = new TransactionAdapter(getContext(), list);
        recyclerView.setAdapter(transAdapter);
        transAdapter.setOnItemClickListener(TransactionsFragment.this);

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        userKey = store.getUid();
        dbTrans = FirebaseDatabase.getInstance().getReference("Transactions").child(userKey);

        newCalendar = Calendar.getInstance();
        StartTime = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int selectedYear,
                                  int selectedMonth, int selectedDay) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(selectedYear, selectedMonth, selectedDay);

                day = selectedDay;
                month = selectedMonth;
                year = selectedYear;

                SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
                date = format.format(newDate.getTime());

                list.clear();
                totalSales.setText("₱0.00");
                totalCost.setText("₱0.00");
                totalDiscount.setText("₱0.00");
                profit.setText("₱0.00");

                Query q = dbTrans.orderByChild("date").equalTo(date);
                q.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        if(dataSnapshot.hasChildren()) {
                            //clears the arrayList
                            list.clear();
                            totalS = 0;
                            totalC = 0;
                            totalD = 0;
                            Transactions trans = null;
                            for (DataSnapshot ds : dataSnapshot.getChildren()) {
                                trans = ds.getValue(Transactions.class);


                                list.add(trans);

                                ts = trans.getAmount();
                                tc = trans.getCamount();
                                td = trans.getDiscount();

                                totalS = totalS + ts;
                                totalC = totalC + tc;
                                totalD = totalD + td;

                                p = totalS - totalC - totalD;

                            }

                            totalSales.setText(String.format("₱%.2f", totalS));
                            totalCost.setText(String.format("-₱%.2f", totalC));
                            totalDiscount.setText(String.format("-₱%.2f", totalD));
                            profit.setText(String.format("₱%.2f", p));
                        }
                        transAdapter.notifyDataSetChanged();
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });

            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));


        result();
        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                int color = getResources().getColor(R.color.colorPrimary);
                swipeRefresh.setColorSchemeColors(color);
                swipeRefresh.setRefreshing(false);
            }
        });
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        MenuInflater in = getActivity().getMenuInflater();
        in.inflate(R.menu.calendar_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.calendar:
                StartTime.show();
                break;
        }
        return true;
    }



    @Override
    public void onItemClick(int position) {

        Transactions trans = list.get(position);
    }

    @Override
    public Dialog onCreateDialog(int id) {
        return null;
    }

    public void result() {

        dbTrans.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                list.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    Transactions trans = postSnapshot.getValue(Transactions.class);

                    list.add(trans);

                    ts = trans.getAmount();
                    tc = trans.getCamount();
                    td = trans.getDiscount();

                    totalS = totalS + ts;
                    totalC = totalC + tc;
                    totalD = totalD + td;

                    p = totalS - totalC - totalD;

                    totalSales.setText(String.format("₱%.2f", totalS));
                    totalCost.setText(String.format("-₱%.2f" , totalC));
                    totalDiscount.setText(String.format("-₱%.2f", totalD));
                    profit.setText(String.format("₱%.2f", p));

                }
                transAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}
