package com.example.kenxhin23.goodbargain;

import android.app.ActionBar;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class
Login extends AppCompatActivity {

    private TextInputLayout layoutEmail;
    private TextInputLayout layoutPass;

    private TextInputEditText editEmail;
    private TextInputEditText editPass;
    private FirebaseAuth auth;

    private AppCompatButton LogBtn;
    private AppCompatTextView RegLink;
    private AppCompatTextView ForgotLink;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser()!= null){
            startActivity(new Intent(Login.this, MainDrawer.class));
            finish();
        }
        setContentView(R.layout.activity_login);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorProgress)));

        initViews();

        auth = FirebaseAuth.getInstance();

        LogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //code here
                String email = editEmail.getText().toString().trim();
                final String pass = editPass.getText().toString().trim();

                if (TextUtils.isEmpty(email)){
                    layoutEmail.setError(getString(R.string.error_message_email));
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    layoutEmail.setError(getString(R.string.error_message_invalid_email));
                    return;
                }
                if (TextUtils.isEmpty(pass)){
                    layoutPass.setError(getString(R.string.error_message_password));
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);

                auth.signInWithEmailAndPassword(email, pass)
                        .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                progressBar.setVisibility(View.GONE);
                                if (!task.isSuccessful()){
                                    if (pass.length() < 8) {
                                        progressBar.setVisibility(View.GONE);
                                        editPass.setError(getString(R.string.error_password_length));;
                                    }else{
                                        progressBar.setVisibility(View.GONE);
                                        Toast.makeText(getApplicationContext(), getString(R.string.auth_failed), Toast.LENGTH_LONG).show();
                                    }
                                } else {
                                    Intent intent = new Intent(Login.this, MainDrawer.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        });

            }
        });

        RegLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent reg = new Intent(getApplicationContext(), Register.class);
                startActivity(reg);
            }
        });

        ForgotLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //code here
                Intent reset = new Intent(getApplicationContext(), ResetPassword.class);
                startActivity(reset);
            }
        });


    }

    @Override
    public void onBackPressed() {

            final AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
            builder.setMessage("Are you sure to exit?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });

            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int i) {
                    dialog.cancel();
                }
            });
            AlertDialog log = builder.create();
            log.show();
    }

//    @Override
//    protected void onStart() {
//        super.onStart();
//
//
//    }

    public void initViews(){

        LogBtn = (AppCompatButton) findViewById(R.id.LogBtn);
        RegLink = (AppCompatTextView) findViewById(R.id.RegLink);
        ForgotLink = (AppCompatTextView) findViewById(R.id.ForgotLink);
        editEmail = (TextInputEditText) findViewById(R.id.EditEmail);
        editPass = (TextInputEditText) findViewById(R.id.EditPass);
        layoutEmail = (TextInputLayout) findViewById(R.id.LayoutEmail);
        layoutPass = (TextInputLayout) findViewById(R.id.LayoutPass);
        progressBar = (ProgressBar) findViewById(R.id.progressbar);
        progressBar.setVisibility(View.GONE);    }
}
