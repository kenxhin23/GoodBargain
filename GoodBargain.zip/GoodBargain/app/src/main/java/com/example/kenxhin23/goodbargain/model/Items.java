package com.example.kenxhin23.goodbargain.model;

/**
 * Created by kenxhin23 on 3/23/2019.
 */

public class Items {

    String id;
    String model;
    String description;
    String quantity;
    String price;
    byte[] img;

    public Items(){
    }

    public Items( String id, String model, String description, String quantity, String price, byte[] img){

        this.id = id;
        this.model = model;
        this.description = description;
        this.quantity = quantity;
        this.price = price;
        this.img = img;

    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public byte[] getImg(){
        return this.img;
    }

    public void setImg(byte[] b){
        this.img = b;
    }
}
