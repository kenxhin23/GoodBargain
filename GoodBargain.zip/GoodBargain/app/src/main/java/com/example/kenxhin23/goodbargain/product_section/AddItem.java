package com.example.kenxhin23.goodbargain.product_section;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.nfc.Tag;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.example.kenxhin23.goodbargain.model.Store;
import com.github.aakira.expandablelayout.ExpandableLayout;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;

public class AddItem extends AppCompatActivity {

    String Storage_path = "Products", storeID;

    private TextInputLayout layoutPname, layoutPrice, layoutDesc, layoutCost, layoutStock;

    private ImageView showImageView;
    private EditText editProductName;
    private EditText editPrice;
    private EditText editCategory;
    private EditText editDescription;
    private EditText editCost;
    private EditText editStock;
    private TextView category;
    private ExpandableLayout expand;

    private Button saveButton;

    int Image_Request_Code = 7;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
    //String id;
    String pid;
    Uri FilePathUri;

    ProgressDialog progressDialog;
    FirebaseDatabase db;
    StorageReference storageReference;
    DatabaseReference databaseReference;
    private final static int MY_REQUEST_CODE = 1;

    String id, name, cat, description, stock, url;
    double price, cost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        setTitle("New Item");

        init();


        storageReference = FirebaseStorage.getInstance().getReference();

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = db.getInstance().getReference("Products").child(userKey);

        progressDialog = new ProgressDialog(AddItem.this);

        showImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i, "Please select image!"), Image_Request_Code);
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UploadProductDetails();
            }
        });

        category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent a = new Intent(AddItem.this, CategoryList.class);
                startActivityForResult(a, MY_REQUEST_CODE);

            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == MY_REQUEST_CODE) {
                if (data != null)
                    category.setText(data.getStringExtra("category"));
            }
        }

        if (requestCode == Image_Request_Code && resultCode == RESULT_OK && data != null && data.getData() != null) {

            FilePathUri = data.getData();

            try {

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), FilePathUri);

                showImageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void UploadProductDetails() {

        if (FilePathUri != null) {

            final double price = parseDouble(editPrice.getText().toString().trim());
            final double cost = parseDouble(editCost.getText().toString().trim());
            final String productName = editProductName.getText().toString().trim();
            final String cat = category.getText().toString().trim();
            final String description = editDescription.getText().toString().trim();
            final String stock = editStock.getText().toString().trim();
            final String pid = databaseReference.push().getKey();


            if (TextUtils.isEmpty(productName)) {
                layoutPname.setError("Enter Name");
                return;
            }
            if (editPrice.getText().toString().trim().isEmpty()) {
                layoutPrice.setError("Enter Price");
                return;
            }
            if (category.getText().equals("Category")) {
                category.setError("Select Category");
                return;
            }
            if (TextUtils.isEmpty(description)) {
                layoutDesc.setError("Enter Description");
                return;
            }
            if (editCost.getText().toString().trim().isEmpty()) {
                layoutCost.setError("Enter Original Price");
                return;
            }
            if (TextUtils.isEmpty(stock)) {
                layoutStock.setError("Enter Quantity");
                return;
            }
            if (price <= cost) {
//                layoutCost.setError("Value must be lower than Price");
                Toast.makeText(this, "Original Price must not be equal or greater than Price", Toast.LENGTH_SHORT).show();
                return;
            }
            progressDialog.setTitle("Saving...");
            progressDialog.show();

            StorageReference storageRef = storageReference.child(Storage_path + System.currentTimeMillis() + "." + GetFileExtension(FilePathUri));

            storageRef.putFile(FilePathUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
                            finish();

                            ProductInfo productInfo = new ProductInfo(
                                    pid,
                                    productName,
                                    price,
                                    cat,
                                    description,
                                    cost,
                                    stock,
                                    taskSnapshot.getDownloadUrl().toString());
                            databaseReference.child(pid).setValue(productInfo);
                        }
                    })

                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                            progressDialog.dismiss();

                            Toast.makeText(AddItem.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })

                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                            progressDialog.setTitle("Saving...");
                        }
                    });
        } else {
            Toast.makeText(this, "Please Select Image", Toast.LENGTH_SHORT).show();
        }
    }

    public String GetFileExtension(Uri uri) {

        ContentResolver contentResolver = getContentResolver();

        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();

        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    public void init() {
        showImageView = (ImageView) findViewById(R.id.showImageView);
        editProductName = (EditText) findViewById(R.id.EditProductName);
        editPrice = (EditText) findViewById(R.id.EditPrice);
        editDescription = (EditText) findViewById(R.id.EditDescription);
        editCost = (EditText) findViewById(R.id.EditCost);
        editStock = (EditText) findViewById(R.id.EditStock);
        layoutPname = (TextInputLayout) findViewById(R.id.LayoutProductName);
        layoutPrice = (TextInputLayout) findViewById(R.id.LayoutPrice);
        layoutDesc = (TextInputLayout) findViewById(R.id.LayoutDescription);
        layoutCost = (TextInputLayout) findViewById(R.id.LayoutCost);
        layoutStock = (TextInputLayout) findViewById(R.id.LayoutStock);
        saveButton = (Button) findViewById(R.id.saveButton);
        category = (TextView) findViewById(R.id.EditCategory);
    }

    private double parseDouble(String s){
        if(s == null || s.isEmpty())
            return 0.0;
        else
            return Double.parseDouble(s);
    }
}

