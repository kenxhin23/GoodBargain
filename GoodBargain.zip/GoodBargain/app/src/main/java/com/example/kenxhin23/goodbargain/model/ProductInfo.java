package com.example.kenxhin23.goodbargain.model;

/**
 * Created by kenxhin23 on 2/5/2020.
 */

public class ProductInfo {

    private String id;
    private String itemName;
    private double price;
    private String stock;
    private String description;
    private double cost;
    private String imageUrl;
    private String category;
    private String store_id;
    private String supplier;

    public ProductInfo(){

    }

    public ProductInfo( String id, String itemName, double price, String category, String description,
    double cost, String stock, String imageUrl) {

        this.id = id;
        this.itemName = itemName;
        this.price = price;
        this.category = category;
        this.description = description;
        this.cost = cost;
        this.stock = stock;
        this.imageUrl = imageUrl;



    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }


}
