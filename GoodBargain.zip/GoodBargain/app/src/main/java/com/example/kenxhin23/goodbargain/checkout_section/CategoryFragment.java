package com.example.kenxhin23.goodbargain.checkout_section;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.CategoryAdapter;
import com.example.kenxhin23.goodbargain.adapters.ProductAdapter;
import com.example.kenxhin23.goodbargain.model.Cart;
import com.example.kenxhin23.goodbargain.model.Category;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.example.kenxhin23.goodbargain.product_section.CategoriesFragment;
import com.example.kenxhin23.goodbargain.product_section.ItemFragment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kenxhin23 on 7/21/2020.
 */

public class CategoryFragment extends Fragment implements ProductAdapter.OnItemClickListener {

    DatabaseReference databaseReference, dbCus, dbProducts;
    RecyclerView recyclerCat;
    Spinner spinnerCat, spinner;
    SwipeRefreshLayout swipeRefresh;
    private FirebaseAuth auth;
    ProgressDialog progressDialog;
    CategoryAdapter cAdapter = null;
    List<Category> list1 = new ArrayList<>();
    List<String> catName = new ArrayList<String>();
    ArrayAdapter<String> dataAdapter;
    List<String> cusName = new ArrayList<String>();
    ProductAdapter pAdapter = null;
    List<ProductInfo> list = new ArrayList<>();
    View v;
    String cus, cusID, img, userKey, pid, pname, cat, desc, stock, category;
    double price, cost;
    int newQty, qty, stk;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.category_list, container, false);
        return v;

    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        swipeRefresh = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefresh);
        recyclerCat = (RecyclerView) view.findViewById(R.id.catRecycleView);
        spinnerCat = (Spinner) view.findViewById(R.id.spinnerCat);

        listMode();

        progressDialog = new ProgressDialog(getActivity());

//        cAdapter = new CategoryAdapter(getContext(), list1);
//        recyclerCat.setAdapter(cAdapter);
//        cAdapter.setOnItemClickListener(CategoryFragment.this);

        pAdapter = new ProductAdapter(getContext(), list);
        recyclerCat.setAdapter(pAdapter);
        pAdapter.setOnItemClickListener(CategoryFragment.this);

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        userKey = store.getUid();
        dbProducts = FirebaseDatabase.getInstance().getReference("Products").child(userKey);


        result();
        res();


        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                int color = getResources().getColor(R.color.colorPrimary);
                swipeRefresh.setColorSchemeColors(color);
                result();
                swipeRefresh.setRefreshing(false);

            }
        });


        spinnerCat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                category = spinnerCat.getSelectedItem().toString();

                databaseReference = FirebaseDatabase.getInstance().getReference("Products").child(userKey);
                Query query = databaseReference.orderByChild("category").equalTo(category);

                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        list.clear();
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                            ProductInfo productInfo = postSnapshot.getValue(ProductInfo.class);

                        list.add(productInfo);
                    }
                        pAdapter.notifyDataSetChanged();
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        MenuInflater in = getActivity().getMenuInflater();
        in.inflate(R.menu.spinner_menu, menu);
        in.inflate(R.menu.add_customer, menu);
        in.inflate(R.menu.view_cart, menu);
        in.inflate(R.menu.list_menu, menu);
        in.inflate(R.menu.grid_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);

        MenuItem item = menu.findItem(R.id.spinner);

        final MenuItem listMode = menu.findItem(R.id.listMode);
        final MenuItem gridMode = menu.findItem(R.id.gridMode);

        spinner = (Spinner) item.getActionView();
        dbCus = FirebaseDatabase.getInstance().getReference("Customer").child(userKey);

        dbCus.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                cusName.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    Customer cus = postSnapshot.getValue(Customer.class);
                    cusName.add(cus.getCusName());
                }

                if (getActivity() != null){
                    dataAdapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_cus, cusName);
                    dataAdapter.setDropDownViewResource(R.layout.spinner_cus);
                    spinner.setAdapter(dataAdapter);
                }
                dataAdapter.notifyDataSetChanged();

            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        listMode.setVisible(false);

        gridMode.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                listMode.setVisible(true);
                gridMode.setVisible(false);
                gridMode();
                return true;
            }
        });

        listMode.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                listMode.setVisible(false);
                gridMode.setVisible(true);
                listMode();
                return true;
            }
        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                cus = spinner.getSelectedItem().toString();
                getCusId();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void getCusId() {

        Query q = dbCus.orderByChild("cusName").equalTo(cus);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                    final Customer customer = snapshot.getValue(Customer.class);

                    //adds the rooms searched to the arrayList
                    cusID = customer.getCustID();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.viewCart:
                if (cusID != null) {
                    Intent i = new Intent(getContext(), CartList.class);
                    i.putExtra("cusID", cusID);
                    i.putExtra("cname", cus);
                    startActivity(i);
                } else  {
                    Toast.makeText(getContext(), "Add new or select customer!", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.addCustomer:
                addCustomer();
                break;
        }
        return true;
    }

    public void addCustomer() {

        TextView title = new TextView(getContext());
        title.setText("Add Customer");
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = LayoutInflater.from(getContext());
        final View dialogView = inflater.inflate(R.layout.add_customer, null);
        dialogBuilder.setView(dialogView);

        final EditText addCus = (EditText) dialogView.findViewById(R.id.cusName);
        final Button btnAdd = (Button) dialogView.findViewById(R.id.btnAddCus);
        final Button btnCancel = (Button) dialogView.findViewById(R.id.btnCancelCus);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = addCus.getText().toString().trim();
                String cid = dbCus.push().getKey();

                if (!TextUtils.isEmpty(name)) {

                    Customer customer = new Customer(
                            cid,
                            name
                    );
                    dbCus.child(cid).setValue(customer)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(getContext(), "Saved", Toast.LENGTH_LONG).show();
                                    b.dismiss();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(getContext(), "Enter customer name!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.dismiss();
            }
        });
    }

    @Override
    public void onItemClick(int position) {
        final ProductInfo productInfo = list.get(position);

        if (cusID != null) {

            pid = productInfo.getID();
            pname = productInfo.getItemName();
            img = productInfo.getImageUrl();
            cat = productInfo.getCategory();
            desc = productInfo.getDescription();
            stock = productInfo.getStock();
            price = productInfo.getPrice();
            cost = productInfo.getCost();

            showAddQuantity(pid, pname, price, cost, stock);

        } else {
            Toast.makeText(getContext(), "Add new or select customer!", Toast.LENGTH_SHORT).show();
        }
    }

    public void result(){

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Category").child(userKey);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                catName.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    Category category = postSnapshot.getValue(Category.class);
                    catName.add(category.getCat());
                }

                if (getActivity() != null){
                    dataAdapter = new ArrayAdapter<String>(getContext(), R.layout.spinner_cat, catName);
                    dataAdapter.setDropDownViewResource(R.layout.spinner_cat);
                    spinnerCat.setAdapter(dataAdapter);
                    dataAdapter.notifyDataSetChanged();
                    progressDialog.dismiss();
                }

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }

    public void showAddQuantity(final String id, final String productName, final double price, final double cost, final String stock){

        TextView title = new TextView(getContext());
        title.setText(productName);
        title.setPadding(10, 10, 10, 10);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(23);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = LayoutInflater.from(getContext());
        final View dialogView = inflater.inflate(R.layout.add_quantity, null);
        dialogBuilder.setView(dialogView);

        final EditText editQty = (EditText) dialogView.findViewById(R.id.editQuantity);
        final Button buttonAdd = (Button) dialogView.findViewById(R.id.buttonAddCart);
        final Button buttonCancel = (Button) dialogView.findViewById(R.id.buttonCancel);

        dialogBuilder.setCustomTitle(title);
        final AlertDialog b = dialogBuilder.create();
        b.show();

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                stk = Integer.parseInt(stock);
                final String Qty = editQty.getText().toString();

                if (!TextUtils.isEmpty(Qty)){

                    qty = Integer.parseInt(editQty.getText().toString());

                    newQty = stk - qty;


                    if (qty <= 0){

                        Toast.makeText(getContext(), "Enter Quantity", Toast.LENGTH_SHORT).show();

                    } else if (stk == 0){

                        Toast.makeText(getContext(), "Out of Stock!", Toast.LENGTH_SHORT).show();
                    } else if (stk < qty){

                        Toast.makeText(getContext(), "Insufficient Stock!", Toast.LENGTH_SHORT).show();
                    } else {

                        update();
                        auth = FirebaseAuth.getInstance();
                        FirebaseUser store = auth.getCurrentUser();
                        final String userKey = store.getUid();
                        databaseReference = FirebaseDatabase.getInstance().getReference("Cart").child(userKey).child(cusID);

                        String cid = databaseReference.push().getKey();
                        double camount = cost * qty;
                        double amount = price * qty;
                        String productID = id;

                        Cart cart = new Cart(
                                cid,
                                cusID,
                                productName,
                                productID,
                                Qty,
                                amount,
                                camount,
                                img
                        );
                        databaseReference.child(cid).setValue(cart)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        result();
                                        Toast.makeText(getContext(), "Item Added!", Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                        b.dismiss();
                                    }
                                });

                        b.dismiss();
//                        Toast.makeText(getContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(getContext(), "Enter Quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b.dismiss();
            }
        });

    }

    public void update() {

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        dbProducts = FirebaseDatabase.getInstance().getReference("Products").child(userKey).child(pid);

        ProductInfo product = new ProductInfo(
                pid,
                pname,
                price,
                cat,
                desc,
                cost,
                ""+newQty,
                img);
        dbProducts.setValue(product)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
//                        Toast.makeText(getContext(), "Item Added!", Toast.LENGTH_LONG).show();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void res(){

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Products").child(userKey);
        databaseReference.orderByChild("category").equalTo(category);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                list.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    ProductInfo productInfo = postSnapshot.getValue(ProductInfo.class);

                    list.add(productInfo);
                }
                pAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }

    public void listMode() {
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
//        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        recyclerCat.setLayoutManager(manager);
        recyclerCat.setHasFixedSize(true);
    }

    public void gridMode() {
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        recyclerCat.setLayoutManager(new GridLayoutManager(getContext(), 2));
//        recyclerView.setLayoutManager(manager);
        recyclerCat.setHasFixedSize(true);
    }
}
