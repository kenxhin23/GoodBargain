package com.example.kenxhin23.goodbargain.model;

public class Transactions {

    String id;
    String custID;
    double discount;
    double amount;
    double camount;
    String date;

    public Transactions() {

    }

    public Transactions(String id, String custID, double discount, double amount, double camount, String date) {
        this.id = id;
        this.custID = custID;
        this.discount = discount;
        this.amount = amount;
        this.camount = camount;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCustID() {
        return custID;
    }

    public void setCustID(String custID) {
        this.custID = custID;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getCamount() {
        return camount;
    }

    public void setCamount(double camount) {
        this.camount = camount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
