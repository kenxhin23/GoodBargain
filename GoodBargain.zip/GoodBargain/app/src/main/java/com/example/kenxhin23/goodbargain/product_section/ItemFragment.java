package com.example.kenxhin23.goodbargain.product_section;

import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.adapters.ProductAdapter;
import com.example.kenxhin23.goodbargain.model.Customer;
import com.example.kenxhin23.goodbargain.model.ProductInfo;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by kenxhin23 on 2/3/2020.
 */

public class ItemFragment extends Fragment implements ProductAdapter.OnItemClickListener{

    DatabaseReference databaseReference;
    SwipeRefreshLayout swipeRefresh;
    RecyclerView  recyclerView;
    private FirebaseAuth auth;
    ProgressDialog progressDialog;
    ProductAdapter pAdapter = null;
    List<ProductInfo> list = new ArrayList<>();
    View v;
    ImageView imageView;
    SearchView searchView;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.item_list, container,false);
        return v;

    }

    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        swipeRefresh = (SwipeRefreshLayout) view.findViewById(R.id.swipeRefresh);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycleView);
        searchView = (SearchView) view.findViewById(R.id.searchItem);


        listMode();

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        pAdapter = new ProductAdapter(getContext(), list);
        recyclerView.setAdapter(pAdapter);
        pAdapter.setOnItemClickListener(ItemFragment.this);


        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Products").child(userKey);

        result();
        refresh();




        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
                public boolean onQueryTextSubmit(String query) {
                firebaseSearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {


                if(!newText.isEmpty()){
                    // call seearch method if user starts typing
                    firebaseSearch(newText);;
                }

                //else
                else{
                    // set TextField empty
                    firebaseSearch("");
                }
                return true;
            }
        });
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        MenuInflater in = getActivity().getMenuInflater();

        in.inflate(R.menu.list_menu, menu);
        in.inflate(R.menu.grid_menu, menu);

        super.onCreateOptionsMenu(menu, inflater);

        MenuItem item = menu.findItem(R.id.spinner);
        final MenuItem listMode = menu.findItem(R.id.listMode);
        final MenuItem gridMode = menu.findItem(R.id.gridMode);

        listMode.setVisible(false);

        gridMode.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                listMode.setVisible(true);
                gridMode.setVisible(false);
                gridMode();
                return true;
            }
        });

        listMode.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                listMode.setVisible(false);
                gridMode.setVisible(true);
                listMode();
                return true;
            }
        });
    }

    private void firebaseSearch(String searchText) {

        //convert string entered in SearchView to lowercase
        String query = searchText.toUpperCase();

        Query q = databaseReference.orderByChild("itemName").startAt(query).endAt(query + "\uf8ff");
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if(dataSnapshot.hasChildren()) {

                    //clears the arrayList
                    list.clear();

                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {

                        final ProductInfo productInfo =
                                snapshot.getValue(ProductInfo.class);

                        //adds the rooms searched to the arrayList
                        list.add(productInfo);
                    }
//                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
//                    ProductInfo productInfo = postSnapshot.getValue(ProductInfo.class);
//                    list.add(productInfo);
//                }
                }
                pAdapter = new ProductAdapter(getContext(), list);
                recyclerView.setAdapter(pAdapter);
                pAdapter.setOnItemClickListener(ItemFragment.this);
                pAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void result(){

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                list.clear();
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                    ProductInfo productInfo = postSnapshot.getValue(ProductInfo.class);

                    list.add(productInfo);
                }
                pAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();
            }
        });
    }

    public void refresh() {
        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                int color = getResources().getColor(R.color.colorPrimary);
                swipeRefresh.setColorSchemeColors(color);
                result();
                swipeRefresh.setRefreshing(false);
            }
        });
    }


    @Override
    public void onItemClick(int position) {
        final ProductInfo productInfo = list.get(position);

        String id = productInfo.getID();
        String name = productInfo.getItemName();
        String category = productInfo.getCategory();
        double price = productInfo.getPrice();
        String description = productInfo.getDescription();
        double cost = productInfo.getCost();
        String stock = productInfo.getStock();
        String url = productInfo.getImageUrl();

        Intent i = new Intent(getActivity(), UpdateItem.class);
        i.putExtra("category", category);
        i.putExtra("id", id);
        i.putExtra("name", name);
        i.putExtra("price", price);
        i.putExtra("description", description);
        i.putExtra("cost", cost);
        i.putExtra("stock", stock);
        i.putExtra("url", url);

        startActivity(i);
    }

    public void listMode() {
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
//        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        recyclerView.setLayoutManager(manager);
        recyclerView.setHasFixedSize(true);
    }

    public void gridMode() {
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
//        recyclerView.setLayoutManager(manager);
        recyclerView.setHasFixedSize(true);
    }
}
