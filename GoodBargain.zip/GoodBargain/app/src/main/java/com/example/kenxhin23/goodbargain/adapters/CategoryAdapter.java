package com.example.kenxhin23.goodbargain.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.Category;
import com.example.kenxhin23.goodbargain.model.ProductInfo;

import java.util.List;

import static com.example.kenxhin23.goodbargain.R.id.itemView;
import static com.example.kenxhin23.goodbargain.R.id.price;

/**
 * Created by kenxhin23 on 7/15/2020.
 */

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    Context context;
    List<Category> CategoryInfoList;
    OnItemClickListener cListener;



    public interface OnItemClickListener{
        void onItemClick (int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        cListener = listener;
    }

    public CategoryAdapter(Context context, List<Category> TempList){
        this.CategoryInfoList = TempList;
        this.context = context;
    }

    @Override
    public CategoryAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_cat, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(CategoryAdapter.ViewHolder holder, int position) {
        Category category = CategoryInfoList.get(position);

        holder.catName.setText(category.getCat());
    }

    @Override
    public int getItemCount() {
        return CategoryInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        public TextView catName;

        public ViewHolder (View itemView){
            super(itemView);


            catName = (TextView) itemView.findViewById(R.id.categoryName);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(cListener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            cListener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }




}
