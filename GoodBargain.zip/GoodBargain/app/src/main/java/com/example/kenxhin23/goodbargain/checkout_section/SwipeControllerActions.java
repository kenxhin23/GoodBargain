package com.example.kenxhin23.goodbargain.checkout_section;


public abstract class SwipeControllerActions {

    public void onLeftClicked(int position) {}

    public void onRightClicked(int position) {}

}
