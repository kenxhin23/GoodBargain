package com.example.kenxhin23.goodbargain.admin_section;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.User_Info;
import com.example.kenxhin23.goodbargain.product_section.UpdateItem;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class UpdateUser extends AppCompatActivity {

    private EditText userName, contact, pin, type;
    private TextInputLayout layoutName, layoutContact, layoutPin, layoutType;
    private Button updateUser;
    private FirebaseAuth auth;

    ProgressDialog progressDialog;
    StorageReference storageReference;
    DatabaseReference databaseReference;

    String id, uname, ucontact, upin, utype;

    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user);
        setTitle("Update");

        init();

        storageReference = FirebaseStorage.getInstance().getReference();

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userKey);

        Intent i = getIntent();
        id = i.getExtras().getString("id");
        uname = i.getExtras().getString("uName");
        ucontact = i.getExtras().getString("contacts");
        upin = i.getExtras().getString("pin");
        utype = i.getExtras().getString("type");

        userName.setText(""+uname);
        contact.setText(""+ucontact);
        pin.setText(""+upin);
        type.setText(""+utype);

        progressDialog = new ProgressDialog(UpdateUser.this);

        updateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update();
            }
        });
    }

    public void init(){
        userName = (EditText) findViewById(R.id.editUsername);
        contact = (EditText) findViewById(R.id.editContact);
        pin = (EditText) findViewById(R.id.editPin);
        type = (EditText) findViewById(R.id.editType);
        updateUser = (Button) findViewById(R.id.saveUser);
        layoutName = (TextInputLayout) findViewById(R.id.layoutUsername);
        layoutContact = (TextInputLayout) findViewById(R.id.layoutContact);
        layoutPin = (TextInputLayout) findViewById(R.id.layoutPin);
        layoutType = (TextInputLayout) findViewById(R.id.layoutType);

    }

    public void update() {

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userKey).child(id);

        String uname = userName.getText().toString().trim();
        String ucontacts = contact.getText().toString().trim();
        String upin = pin.getText().toString().trim();
        String utype = type.getText().toString().trim();
        String uid = id;

        if (TextUtils.isEmpty(uname)) {
            layoutName.setError("Enter Name");
            return;
        }
        if (TextUtils.isEmpty(ucontacts)) {
            layoutContact.setError("Enter Contact Number");
            return;
        }
        if (TextUtils.isEmpty(utype)) {
            layoutType.setError("Please input user type");
            return;
        }
        if (upin.length() < 4) {
            layoutPin.setError("Enter at least 4 digits");
            return;
        }
        if (upin.length() > 4) {
            layoutPin.setError("Please enter not more than 4 digits");
            return;
        }


        progressDialog.setTitle("Saving...");
        progressDialog.show();

        User_Info userInfo = new User_Info(
                uid,
                uname,
                ucontacts,
                upin,
                utype);
        databaseReference.setValue(userInfo)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                        progressDialog.dismiss();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(UpdateUser.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.delete_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.delete:

                final AlertDialog.Builder builder = new AlertDialog.Builder(context);

                builder.setTitle("Delete User");
                builder.setMessage("Are you sure? This action cannot be undone.");

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        delete();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog log = builder.create();
                log.show();

                break;

        }
        return true;
    }

    public void delete(){

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userKey).child(id);

        databaseReference.removeValue();

        Toast.makeText(getApplicationContext(), "User Deleted", Toast.LENGTH_LONG).show();
        finish();
    }
}