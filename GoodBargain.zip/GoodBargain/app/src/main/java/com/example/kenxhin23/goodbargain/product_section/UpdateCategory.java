package com.example.kenxhin23.goodbargain.product_section;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.design.widget.TextInputLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kenxhin23.goodbargain.R;
import com.example.kenxhin23.goodbargain.model.Category;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.w3c.dom.Text;

public class UpdateCategory extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private TextInputLayout layoutUpdateCat;
    private EditText editCategoryName;
    private Button update;
    String id, category;
    Context context = this;

    private FirebaseAuth auth;

    ProgressDialog progressDialog;
    FirebaseDatabase db;
    StorageReference storageReference;
    DatabaseReference databaseReference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_category);
        setTitle("Update Category");

        init();

        storageReference = FirebaseStorage.getInstance().getReference();

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Category").child(userKey);

        Intent i = getIntent();
        id = i.getExtras().getString("id");
        category = i.getExtras().getString("category");

        tabLayout.setupWithViewPager(viewPager);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);

        editCategoryName.setText(""+ category);
        progressDialog = new ProgressDialog(UpdateCategory.this);



        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                update();


            }
        });

    }

    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.delete_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.delete:

                final AlertDialog.Builder builder = new AlertDialog.Builder(context);

                builder.setTitle("Delete Category");
                builder.setMessage("Are you sure? This action cannot be undone.");

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        delete();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog log = builder.create();
                log.show();

                break;

        }
        return true;
    }




    public void init(){

        tabLayout = (TabLayout)findViewById(R.id.tablayout);
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        layoutUpdateCat = (TextInputLayout) findViewById(R.id.layoutUpdateCat);
        editCategoryName = (EditText) findViewById(R.id.editUpdateCategory);
        update  = (Button) findViewById(R.id.updateCat);
    }

    public void update(){

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("Category").child(userKey).child(id);

        String cat =  editCategoryName.getText().toString().trim();
        String cid = id;

        if (TextUtils.isEmpty(cat)) {
            layoutUpdateCat.setError("Enter Category");
            return;
        }

        progressDialog.setTitle("Saving...");
        progressDialog.show();
        Category category = new Category(cid, cat);
        databaseReference.setValue(category)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                        progressDialog.dismiss();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();

                        Toast.makeText(UpdateCategory.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }

    public void delete(){

        auth = FirebaseAuth.getInstance();
        FirebaseUser store = auth.getCurrentUser();
        final String userKey = store.getUid();

        databaseReference = FirebaseDatabase.getInstance().getReference("Category").child(userKey).child(id);

        databaseReference.removeValue();

        Toast.makeText(getApplicationContext(), "Category Deleted", Toast.LENGTH_LONG).show();
        finish();

    }
}
