package com.example.kenxhin23.goodbargain.model;

/**
 * Created by kenxhin23 on 2/2/2020.
 */

public class Store {

    private String id;
    private String storename;
    private String owner_name;
    private String email;
    private String password;

    public Store(){

    }

    public Store(String id, String storename, String owner_name, String email, String password){

        this.id = id;
        this.storename = storename;
        this.owner_name = owner_name;
        this.email = email;
        this.password = password;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getStoreName() {
        return storename;
    }

    public void setStoreName(String storename) {
        this.storename = storename;
    }

    public String getOwnerName() {
        return owner_name;
    }

    public void setOwnerName(String owner_name) {
        this.owner_name = owner_name;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}
