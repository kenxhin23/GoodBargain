package com.example.kenxhin23.goodbargain.model;

public class User_Info {

    String id;
    String userName;
    String contacts;
    String pin;
    String type;

    public User_Info(){
    }

    public User_Info(String id, String userName, String contacts, String pin, String type) {

        this.id = id;
        this.userName = userName;
        this.contacts = contacts;
        this.pin = pin;
        this.type = type;

    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
